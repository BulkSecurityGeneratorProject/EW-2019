-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table `user`  add column  `group_oid`  integer;
alter table `user`   add index fk_user_group_2 (`group_oid`), add constraint fk_user_group_2 foreign key (`group_oid`) references `group` (`oid`);


-- Aposta_Participante [rel1]
alter table `participante`  add column  `aposta_oid`  integer;
alter table `participante`   add index fk_participante_aposta (`aposta_oid`), add constraint fk_participante_aposta foreign key (`aposta_oid`) references `aposta` (`oid`);


-- EventoParticipante [rel3]
alter table `participante`  add column  `evento_evento_oid`  integer;
alter table `participante`   add index fk_participante_evento_2 (`evento_evento_oid`), add constraint fk_participante_evento_2 foreign key (`evento_evento_oid`) references `evento` (`evento_oid`);


