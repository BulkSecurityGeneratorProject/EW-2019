insert into module values(1,"area3","Administrador");
insert into module values (2,"page2","Eventos");
insert into module values(3, "page5", "Apostas");
insert into module values (4,"area9","Historico");
insert into module values (5,"area7","Premium");
insert into module values (6,"area2","Eventos e Apostas");
insert into module values (7,"page1","Perfil");


insert into ew_1029.group values(1,"administrador",1);
insert into ew_1029.group values(2,"premium",2);
insert into ew_1029.group values(3,"normal", 3);


insert into user values(1,"admin","admin",null,9999,1);
insert into user values(2,"joao","joao","Jonas_Filipe_9@hotmail.com", 10000, 2);
insert into user values(3,"user","user","user",30,3);


insert into group_module values(1,1);
insert into group_module values(1,2);
insert into group_module values(1,3);
insert into group_module values(2,2);
insert into group_module values(2,3);
insert into group_module values(3,3);
insert into group_module values(1,4);
insert into group_module values(2,4);
insert into group_module values(1,5);
insert into group_module values(3,5);
insert into group_module values(1,6);
insert into group_module values(2,6);
insert into group_module values(3,6);
insert into group_module values(1,7);
insert into group_module values(2,7);
insert into group_module values(3,7);


INSERT INTO `evento` VALUES (2,'2019-04-02 00:00:00','2019-04-16 00:00:00',4,'Aberto','','\0',7,'Tenis','');
INSERT INTO `evento` VALUES(3,'2019-04-02 00:00:00','2019-04-08 00:00:00',2,'Aberto','','',3.4,'Futebol','\0');
INSERT INTO `evento` VALUES(4,'2019-04-11 00:00:00','2019-04-26 00:00:00',2,'Aberto','','',3.4,'Futebol','');
INSERT INTO `evento` VALUES(5,'2019-04-18 00:00:00','2019-04-27 00:00:00',2,'Fechado','','\0',7,'Tenis','');


INSERT INTO `participante` VALUES (3,'João',2.3,'','Portugal',2);
INSERT INTO `participante` VALUES(4,'Tiago',2.3,'','Portugal',2);
INSERT INTO `participante` VALUES(5,'Stuart',2.2,'','Reino Unido',2);
INSERT INTO `participante` VALUES(6,'Mario',2,'','Brasil',2);
INSERT INTO `participante` VALUES(7,'Moreira',2.9,'Moreira','Portugal',3);
INSERT INTO `participante` VALUES(8,'Maritmo',3,'Maritmo','Portugal',3);
INSERT INTO `participante` VALUES(9,'Braga',2.3,'Braga','Portugal',4);
INSERT INTO `participante` VALUES(10,'Portimão',5,'Portimão','Portugal',4);
INSERT INTO `participante` VALUES(11,'Diogo',2.3,'','Portugal',5);
INSERT INTO `participante` VALUES(12,'Luis',2.2,'','Portugal',5);


INSERT INTO `aposta` VALUES (4,'Aberto',34,0,3,1,2);
INSERT INTO `aposta` VALUES(5,'Aberto',56,0,10,3,4);
INSERT INTO `aposta` VALUES(6,'Aberto',100,0,8,1,3);
INSERT INTO `aposta` VALUES(7,'Aberto',23,0,7,2,3);
INSERT INTO `aposta` VALUES(8,'Fechado',45,0,12,1,5);










