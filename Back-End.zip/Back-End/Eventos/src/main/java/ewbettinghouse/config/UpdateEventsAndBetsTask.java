package ewbettinghouse.config;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;

import ewbettinghouse.domain.Evento;
import ewbettinghouse.repository.EventoRepository;
import ewbettinghouse.service.EventoService;
import ewbettinghouse.service.dto.EventoDTO;
import ewbettinghouse.web.rest.EventoResource;

@Component
public class UpdateEventsAndBetsTask {
	
	 private static final Logger log = LoggerFactory.getLogger(UpdateEventsAndBetsTask.class);
	 
	 @Inject
	 private EventoService eventoService;
	 
	 @Inject
	 private EventoRepository eventoRepository;
	 
	 @Inject
	 private EventoResource ev;

	    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

	  /* @Scheduled(fixedRate = 15000)
	    public void reportCurrentTime() throws ParseException{
	        log.info("Update events", dateFormat.format(new Date()));
	        List<EventoDTO> eventList = new ArrayList<EventoDTO>();
	        eventList = eventoService.fechaEventos();
	        System.out.println("");
	        log.info("Lista de eventos", eventList);
	        
	      //Info do evento do microservico dos eventos
			
			List<Evento> eventoInfo = new ArrayList<Evento>();
			
			System.out.println(eventoInfo);
			System.out.println(ev.estadoEvento(7L, "aberto").toString());
	       
	    }*/
	    
	    
}
