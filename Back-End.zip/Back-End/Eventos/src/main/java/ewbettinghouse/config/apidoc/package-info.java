/**
 * Swagger api specific code.
 */
package ewbettinghouse.config.apidoc;