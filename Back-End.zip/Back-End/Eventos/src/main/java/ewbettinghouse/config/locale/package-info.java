/**
 * Locale specific code.
 */
package ewbettinghouse.config.locale;
