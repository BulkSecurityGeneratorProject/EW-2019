/**
 * Async helpers.
 */
package ewbettinghouse.async;
