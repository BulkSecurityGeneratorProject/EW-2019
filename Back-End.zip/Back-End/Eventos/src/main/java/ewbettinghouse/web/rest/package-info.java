/**
 * Spring MVC REST controllers.
 */
package ewbettinghouse.web.rest;
