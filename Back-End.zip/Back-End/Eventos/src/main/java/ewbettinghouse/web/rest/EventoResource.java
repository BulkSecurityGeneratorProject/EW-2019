package ewbettinghouse.web.rest;

import com.codahale.metrics.annotation.Timed;


import ewbettinghouse.service.EventoService;
import ewbettinghouse.web.rest.util.HeaderUtil;
import ewbettinghouse.web.rest.util.PaginationUtil;
import ewbettinghouse.service.dto.EventoDTO;

import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * REST controller for managing Evento.
 */
@RestController
@RequestMapping("/api")
public class EventoResource {

    private final Logger log = LoggerFactory.getLogger(EventoResource.class);
        
    @Inject
    private EventoService eventoService;

    /**
     * POST  /eventos : Create a new evento.
     *
     * @param eventoDTO the eventoDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new eventoDTO, or with status 400 (Bad Request) if the evento has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/eventos")
    @Timed
    public ResponseEntity<EventoDTO> createEvento(@Valid @RequestBody EventoDTO eventoDTO) throws URISyntaxException {
        log.debug("REST request to save Evento : {}", eventoDTO);
        if (eventoDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("evento", "idexists", "A new evento cannot already have an ID")).body(null);
        }
        EventoDTO result = eventoService.save(eventoDTO);
        return ResponseEntity.created(new URI("/api/eventos/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("evento", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /eventos : Updates an existing evento.
     *
     * @param eventoDTO the eventoDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated eventoDTO,
     * or with status 400 (Bad Request) if the eventoDTO is not valid,
     * or with status 500 (Internal Server Error) if the eventoDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/eventos")
    @Timed
    public ResponseEntity<EventoDTO> updateEvento(@Valid @RequestBody EventoDTO eventoDTO) throws URISyntaxException {
        log.debug("REST request to update Evento : {}", eventoDTO);
        if (eventoDTO.getId() == null) {
            return createEvento(eventoDTO);
        }
        EventoDTO result = eventoService.save(eventoDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("evento", eventoDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /eventos : get all the eventos.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of eventos in body
     * @throws URISyntaxException if there is an error to generate the pagination HTTP headers
     */
   /* @GetMapping("/eventos")
    @Timed
    public ResponseEntity<List<EventoDTO>> getAllEventos(@ApiParam Pageable pageable)
        throws URISyntaxException {
        log.debug("REST request to get a page of Eventos");
        Page<EventoDTO> page = eventoService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/eventos");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }*/

    /**
     * GET  /eventos/:id : get the "id" evento.
     *
     * @param id the id of the eventoDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the eventoDTO, or with status 404 (Not Found)
     */
    @GetMapping("/eventos/{id}")
    @Timed
    public ResponseEntity<EventoDTO> getEvento(@PathVariable Long id) {
        log.debug("REST request to get Evento : {}", id);
        EventoDTO eventoDTO = eventoService.findOne(id);
        return Optional.ofNullable(eventoDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /eventos/:id : delete the "id" evento.
     *
     * @param id the id of the eventoDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/eventos/{id}")
    @Timed
    public ResponseEntity<Void> deleteEvento(@PathVariable Long id) {
        log.debug("REST request to delete Evento : {}", id);
        eventoService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("evento", id.toString())).build();
    }
    
    
    //Adiciona Evento
    @GetMapping("/eventos/adicionarEvento/{horaInicio}/{horaFim}/{n_participantes}/{estado}/{vencedor}/{evento_equipa}/{odd_empate}"
    		+ "/{desporto}/{publico}")
    public ResponseEntity<List<EventoDTO>> adicionaEvento(@PathVariable String horaInicio, @PathVariable String horaFim, @PathVariable int n_participantes,
    		@PathVariable String estado, @PathVariable String vencedor, @PathVariable boolean evento_equipa, @PathVariable double odd_empate, @PathVariable String desporto,
    		@PathVariable boolean publico) {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.adicionaEvento(horaInicio, horaFim, n_participantes, estado, vencedor, evento_equipa, odd_empate,
        			 desporto, publico);
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    }
    
    //Apaga Evento
    @GetMapping("/eventos/apagarEvento/{id}")
    public ResponseEntity<List<EventoDTO>> apagaEvento(@PathVariable Long id) {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.apagaEvento(id);
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    }
    
    //Updates a eventos
    
    //Atribuir vencedor a Evento
    @GetMapping("/eventos/vencedor/{id}/{vencedor}")
    public ResponseEntity<List<EventoDTO>> updateVencedorEvento( @PathVariable Long id, @PathVariable String vencedor) {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.vencedorEvento(id, vencedor);
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    }
    
    @GetMapping("/eventos/upadateEvento/{id}/{horaInicio}/{horaFim}/{n_participantes}/{estado}/{vencedor}/{evento_equipa}/{odd_empate}/{desporto}/{publico}")
    public ResponseEntity<List<EventoDTO>> updateEvento( @PathVariable Long id,@PathVariable String horaInicio, @PathVariable String horaFim, @PathVariable int n_participantes,
    		@PathVariable String estado, @PathVariable String vencedor, @PathVariable boolean evento_equipa, @PathVariable double odd_empate, @PathVariable String desporto,
    		@PathVariable boolean publico) {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.updateEvento(id, horaInicio, horaFim,n_participantes, estado,
        				vencedor, evento_equipa,odd_empate, desporto,  publico);
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    }
    
    //Mudar estado a Evento
    @GetMapping("/eventos/estado/{id}/{estado}")
    public ResponseEntity<List<EventoDTO>> estadoEvento( @PathVariable Long id, @PathVariable String estado) {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.estadoEvento(id, estado);
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    }
    
    //todos os eventos
    @GetMapping("/eventos")
    public ResponseEntity<List<EventoDTO>> todosEventos() {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.todosEventos();
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    	
    }
    
    //Todos os eventos abertos privados e publicos
    @GetMapping("/eventos/abertos")
    public ResponseEntity<List<EventoDTO>> abertosEventos() {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.abertosEventos();
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    	
    }
    
    //Todos os eventos publicos abertos
    @GetMapping("/eventos/publicos")
    public ResponseEntity<List<EventoDTO>> publicosEventos() {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.publicosEventos();
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    	
    }
    
    //Todos os eventos privados abertos
    @GetMapping("/eventos/privados")
    public ResponseEntity<List<EventoDTO>> privadosEventos() {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.privadosEventos();
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    	
    }
    
  //Todos os eventos que fecharam 1 dia
    @GetMapping("/eventos/fecharamRecetemente")
    public ResponseEntity<List<EventoDTO>> fecharamRecetemente() {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.fecharamRecetemente();
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    	
    }
    
    //Todos os eventos fechados
    @GetMapping("/eventos/fechados")
    public ResponseEntity<List<EventoDTO>> fechadosEventos() {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.fechadosEventos();
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    	
    }
    
  //Fecha os eventos fim > inicio
    @GetMapping("/eventos/fechaEventos")
    public ResponseEntity<List<EventoDTO>> fechaEventos() {
    	 List<EventoDTO> listaEventos = null;
         try {
        	 listaEventos = eventoService.fechaEventos();
     	} catch (Exception e) {
     	    log.error("ERROR : " + e.getMessage());
     	}
         return new ResponseEntity<>(listaEventos, HttpStatus.OK);
    	
    }
    
   

}
