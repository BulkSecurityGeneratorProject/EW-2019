package ewbettinghouse.web.rest;

import com.codahale.metrics.annotation.Timed;
import ewbettinghouse.service.ParticipanteService;
import ewbettinghouse.web.rest.util.HeaderUtil;
import ewbettinghouse.web.rest.util.PaginationUtil;
import ewbettinghouse.service.dto.EventoDTO;
import ewbettinghouse.service.dto.ParticipanteDTO;

import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * REST controller for managing Participante.
 */
@RestController
@RequestMapping("/api")
public class ParticipanteResource {

    private final Logger log = LoggerFactory.getLogger(ParticipanteResource.class);
        
    @Inject
    private ParticipanteService participanteService;

    /**
     * POST  /participantes : Create a new participante.
     *
     * @param participanteDTO the participanteDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new participanteDTO, or with status 400 (Bad Request) if the participante has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/participantes")
    @Timed
    public ResponseEntity<ParticipanteDTO> createParticipante(@Valid @RequestBody ParticipanteDTO participanteDTO) throws URISyntaxException {
        log.debug("REST request to save Participante : {}", participanteDTO);
        if (participanteDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("participante", "idexists", "A new participante cannot already have an ID")).body(null);
        }
        ParticipanteDTO result = participanteService.save(participanteDTO);
        return ResponseEntity.created(new URI("/api/participantes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("participante", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /participantes : Updates an existing participante.
     *
     * @param participanteDTO the participanteDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated participanteDTO,
     * or with status 400 (Bad Request) if the participanteDTO is not valid,
     * or with status 500 (Internal Server Error) if the participanteDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/participantes")
    @Timed
    public ResponseEntity<ParticipanteDTO> updateParticipante(@Valid @RequestBody ParticipanteDTO participanteDTO) throws URISyntaxException {
        log.debug("REST request to update Participante : {}", participanteDTO);
        if (participanteDTO.getId() == null) {
            return createParticipante(participanteDTO);
        }
        ParticipanteDTO result = participanteService.save(participanteDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("participante", participanteDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /participantes : get all the participantes.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of participantes in body
     * @throws URISyntaxException if there is an error to generate the pagination HTTP headers
     */
    @GetMapping("/participantes")
    @Timed
    public ResponseEntity<List<ParticipanteDTO>> getAllParticipantes(@ApiParam Pageable pageable)
        throws URISyntaxException {
        log.debug("REST request to get a page of Participantes");
        Page<ParticipanteDTO> page = participanteService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/participantes");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /**
     * GET  /participantes/:id : get the "id" participante.
     *
     * @param id the id of the participanteDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the participanteDTO, or with status 404 (Not Found)
     */
    @GetMapping("/participantes/{id}")
    @Timed
    public ResponseEntity<ParticipanteDTO> getParticipante(@PathVariable Long id) {
        log.debug("REST request to get Participante : {}", id);
        ParticipanteDTO participanteDTO = participanteService.findOne(id);
        return Optional.ofNullable(participanteDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /participantes/:id : delete the "id" participante.
     *
     * @param id the id of the participanteDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/participantes/{id}")
    @Timed
    public ResponseEntity<Void> deleteParticipante(@PathVariable Long id) {
        log.debug("REST request to delete Participante : {}", id);
        participanteService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("participante", id.toString())).build();
    }
    
    
    @GetMapping("/participantes/registar/{evento}/{nome}/{odd_vencer}/{equipa}/{pais}")
    @Timed
    public ResponseEntity<List<ParticipanteDTO>> registaParticipante(@PathVariable Long evento, @PathVariable String nome, @PathVariable double odd_vencer,
    		@PathVariable String equipa, @PathVariable String pais) {
        List<ParticipanteDTO> listaParticipantes = null;
        try {
        	listaParticipantes = participanteService.registaParticipante(evento,nome,odd_vencer,equipa,pais);
    	} catch (Exception e) {
    	    log.error("ERROR : " + e.getMessage());
    	}
        return new ResponseEntity<>(listaParticipantes, HttpStatus.OK);
    }
    
    @GetMapping("/participantes/eliminar/{id}")
    @Timed
    public ResponseEntity<List<ParticipanteDTO>> apagaParticipante(@PathVariable Long id) {
        List<ParticipanteDTO> listaParticipantes = null;
        try {
        	listaParticipantes = participanteService.apagaParticipante(id);
    	} catch (Exception e) {
    	    log.error("ERROR : " + e.getMessage());
    	}
        return new ResponseEntity<>(listaParticipantes, HttpStatus.OK);
    }
    
    @GetMapping("/participantes/evento/{id}")
    @Timed
    public ResponseEntity<List<ParticipanteDTO>> eventoParticipantes(@PathVariable Long id) {
        List<ParticipanteDTO> listaParticipantes = null;
        try {
        	listaParticipantes = participanteService.eventoParticipantes(id);
    	} catch (Exception e) {
    	    log.error("ERROR : " + e.getMessage());
    	}
        return new ResponseEntity<>(listaParticipantes, HttpStatus.OK);
    }
    
    
    
    
    


}
