package ewbettinghouse.repository;

import ewbettinghouse.domain.Evento;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the Evento entity.
 */
@SuppressWarnings("unused")
public interface EventoRepository extends JpaRepository<Evento,Long> {
	
	List<Evento> findAll();
	
	Evento findEventoById(@Param("id") Long id);
	
	List<Evento> findAllByEstado(@Param("estado") String estado);
	
	List<Evento> findAllByPublicoAndEstado(@Param("publico") boolean publico,@Param("estado") String estado);
	

}
