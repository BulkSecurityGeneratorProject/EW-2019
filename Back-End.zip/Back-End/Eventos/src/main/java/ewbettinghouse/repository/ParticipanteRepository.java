package ewbettinghouse.repository;

import ewbettinghouse.domain.Evento;
import ewbettinghouse.domain.Participante;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the Participante entity.
 */
@SuppressWarnings("unused")
public interface ParticipanteRepository extends JpaRepository<Participante,Long> {
	
	List<Participante> findAllByEvento(@Param("evento") Evento evento);
	
	Participante findParticipanteById(@Param("id") Long id);

}
