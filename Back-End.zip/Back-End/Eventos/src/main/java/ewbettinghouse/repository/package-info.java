/**
 * Spring Data JPA repositories.
 */
package ewbettinghouse.repository;
