package ewbettinghouse.service.impl;

import ewbettinghouse.service.EventoService;
import ewbettinghouse.domain.Evento;
import ewbettinghouse.repository.EventoRepository;
import ewbettinghouse.service.dto.EventoDTO;
import ewbettinghouse.service.mapper.EventoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing Evento.
 */
@Service
@Transactional
public class EventoServiceImpl implements EventoService{

    private final Logger log = LoggerFactory.getLogger(EventoServiceImpl.class);
    
    @Inject
    private EventoRepository eventoRepository;

    @Inject
    private EventoMapper eventoMapper;

    /**
     * Save a evento.
     *
     * @param eventoDTO the entity to save
     * @return the persisted entity
     */
    public EventoDTO save(EventoDTO eventoDTO) {
        log.debug("Request to save Evento : {}", eventoDTO);
        Evento evento = eventoMapper.eventoDTOToEvento(eventoDTO);
        evento = eventoRepository.save(evento);
        EventoDTO result = eventoMapper.eventoToEventoDTO(evento);
        return result;
    }

    /**
     *  Get all the eventos.
     *  
     *  @param pageable the pagination information
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public Page<EventoDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Eventos");
        Page<Evento> result = eventoRepository.findAll(pageable);
        return result.map(evento -> eventoMapper.eventoToEventoDTO(evento));
    }

    /**
     *  Get one evento by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public EventoDTO findOne(Long id) {
        log.debug("Request to get Evento : {}", id);
        Evento evento = eventoRepository.findOne(id);
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);
        return eventoDTO;
    }

    /**
     *  Delete the  evento by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Evento : {}", id);
        eventoRepository.delete(id);
    }

	@Override
	public List<EventoDTO> adicionaEvento(String horaInicio, String horaFim, int n_participantes, String estado,
			String vencedor, boolean evento_equipa, double odd_empate, String desporto, boolean publico) {
		
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		
		Evento novoEvento = new Evento();
		novoEvento.setHoraInicio(horaInicio);
		novoEvento.setHoraFim(horaFim);
		novoEvento.setn_participante(n_participantes);
		novoEvento.setEstado(estado);
		novoEvento.setVencedor(vencedor);
		novoEvento.setEvento_equipa(evento_equipa);
		novoEvento.setOdd_empate(odd_empate);
		novoEvento.setDesporto(desporto);
		novoEvento.setPublico(publico);
		
		eventoRepository.saveAndFlush(novoEvento);
		
		List<Evento> listaEventos = eventoRepository.findAll();
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}

	@Override
	public List<EventoDTO> apagaEvento(Long id) {
		
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		
		Evento evento = new Evento();
		evento = eventoRepository.findEventoById(id);
		eventoRepository.delete(evento);
		
		List<Evento> listaEventos = eventoRepository.findAll();
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}

	@Override
	public List<EventoDTO> vencedorEvento(Long id, String vencedor) {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		
		Evento evento = new Evento();
		evento = eventoRepository.findEventoById(id);
		
		
		evento.setVencedor(vencedor);
		evento.setEstado("fechado");
		eventoRepository.saveAndFlush(evento);
		
		List<Evento> listaEventos = eventoRepository.findAll();
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;

	}
	
	@Override
	public List<EventoDTO>estadoEvento(Long id, String estado) {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		
		Evento evento = new Evento();
		evento = eventoRepository.findEventoById(id);
		
		
		evento.setEstado(estado);
		eventoRepository.saveAndFlush(evento);
		
		List<Evento> listaEventos = eventoRepository.findAll();
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;

	}
	
	private Evento eventoId(long id) {
		Evento evento = new Evento();
		evento = eventoRepository.findEventoById(id);
		return evento;
	}

	@Override
	public List<EventoDTO> todosEventos() {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		List<Evento> listaEventos = eventoRepository.findAll();
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}

	@Override
	public List<EventoDTO> abertosEventos() {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		List<Evento> listaEventos = eventoRepository.findAllByEstado("aberto");
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}

	@Override
	public List<EventoDTO> publicosEventos() {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		List<Evento> listaEventos = eventoRepository.findAllByPublicoAndEstado(true, "aberto");
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}

	@Override
	public List<EventoDTO> privadosEventos() {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		List<Evento> listaEventos = eventoRepository.findAllByPublicoAndEstado(false, "aberto");
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}

	@Override
	public List<EventoDTO> fecharamRecetemente() throws ParseException {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		List<Evento> listaEventos = eventoRepository.findAllByEstado("aberto");
		
		List<Evento> listaEventosTodos = eventoRepository.findAllByEstado("fechado");
		
		Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());
		
		for(Evento e : listaEventosTodos) {
			
			
			    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			    Date parsedDate = dateFormat.parse(e.getHoraFim());
			    Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
			    int diffInDays = getDaysBetween(ts, timestamp);
			    System.out.println("HEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEY");
			    System.out.println("HEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEY");
			    System.out.println("HEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEY");
			    System.out.println("HEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEY");
			    System.out.println("HEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEY");
			    System.out.println(diffInDays);
			    if(diffInDays < 2 && diffInDays >= 0) {
			    	listaEventos.add(e);
			    }
		
			
		}
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}
	
	private int getDaysBetween (Timestamp start, Timestamp end)   {

	      boolean negative = false;
	      if (end.before(start))  {
	          negative = true;
	          Timestamp temp = start;
	          start = end;
	          end = temp;
	      }

	      GregorianCalendar cal = new GregorianCalendar();
	      cal.setTime(start);
	      cal.set(Calendar.HOUR_OF_DAY, 0);
	      cal.set(Calendar.MINUTE, 0);
	      cal.set(Calendar.SECOND, 0);
	      cal.set(Calendar.MILLISECOND, 0);

	      GregorianCalendar calEnd = new GregorianCalendar();
	      calEnd.setTime(end);
	      calEnd.set(Calendar.HOUR_OF_DAY, 0);
	      calEnd.set(Calendar.MINUTE, 0);
	      calEnd.set(Calendar.SECOND, 0);
	      calEnd.set(Calendar.MILLISECOND, 0);


	      if (cal.get(Calendar.YEAR) == calEnd.get(Calendar.YEAR))   {
	          if (negative)
	               return (calEnd.get(Calendar.DAY_OF_YEAR) - cal.get(Calendar.DAY_OF_YEAR)) * -1;
	          return calEnd.get(Calendar.DAY_OF_YEAR) - cal.get(Calendar.DAY_OF_YEAR);
	      }

	      int days = 0;
	      while (calEnd.after(cal))    {
	          cal.add (Calendar.DAY_OF_YEAR, 1);
	          days++;
	      }
	      if (negative)
	          return days * -1;
	      return days;
	  }

	@Override
	public List<EventoDTO> fechadosEventos() {
		List<EventoDTO> listaEventosDTO = new ArrayList<EventoDTO>();
		List<Evento> listaEventos = eventoRepository.findAllByEstado("fechado");
		listaEventosDTO = eventoMapper.eventosToEventoDTOs(listaEventos);
		
		return listaEventosDTO;
	}
	
	
}
