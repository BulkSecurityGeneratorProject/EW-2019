/**
 * Service layer beans.
 */
package ewbettinghouse.service;
