package ewbettinghouse.service.mapper;

import ewbettinghouse.domain.*;
import ewbettinghouse.service.dto.ParticipanteDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Participante and its DTO ParticipanteDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ParticipanteMapper {

    @Mapping(source = "evento.id", target = "eventoId")
    ParticipanteDTO participanteToParticipanteDTO(Participante participante);

    List<ParticipanteDTO> participantesToParticipanteDTOs(List<Participante> participantes);

    @Mapping(source = "eventoId", target = "evento")
    Participante participanteDTOToParticipante(ParticipanteDTO participanteDTO);

    List<Participante> participanteDTOsToParticipantes(List<ParticipanteDTO> participanteDTOs);

    default Evento eventoFromId(Long id) {
        if (id == null) {
            return null;
        }
        Evento evento = new Evento();
        evento.setId(id);
        return evento;
    }
}
