package ewbettinghouse.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Participante entity.
 */
public class ParticipanteDTO implements Serializable {

    private Long id;

    @NotNull
    private String nome;

    @NotNull
    private Double odd_vencer;

    private String equipa;

    private String pais;


    private Long eventoId;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public Double getOdd_vencer() {
        return odd_vencer;
    }

    public void setOdd_vencer(Double odd_vencer) {
        this.odd_vencer = odd_vencer;
    }
    public String getEquipa() {
        return equipa;
    }

    public void setEquipa(String equipa) {
        this.equipa = equipa;
    }
    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public Long getEventoId() {
        return eventoId;
    }

    public void setEventoId(Long eventoId) {
        this.eventoId = eventoId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ParticipanteDTO participanteDTO = (ParticipanteDTO) o;

        if ( ! Objects.equals(id, participanteDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "ParticipanteDTO{" +
            "id=" + id +
            ", nome='" + nome + "'" +
            ", odd_vencer='" + odd_vencer + "'" +
            ", equipa='" + equipa + "'" +
            ", pais='" + pais + "'" +
            '}';
    }
}
