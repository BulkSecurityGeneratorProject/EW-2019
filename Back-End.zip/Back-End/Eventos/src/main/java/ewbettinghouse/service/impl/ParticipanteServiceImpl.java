package ewbettinghouse.service.impl;

import ewbettinghouse.service.ParticipanteService;
import ewbettinghouse.domain.Evento;
import ewbettinghouse.domain.Participante;
import ewbettinghouse.repository.EventoRepository;
import ewbettinghouse.repository.ParticipanteRepository;
import ewbettinghouse.service.dto.ParticipanteDTO;
import ewbettinghouse.service.mapper.ParticipanteMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing Participante.
 */
@Service
@Transactional
public class ParticipanteServiceImpl implements ParticipanteService{

    private final Logger log = LoggerFactory.getLogger(ParticipanteServiceImpl.class);
    
    @Inject
    private ParticipanteRepository participanteRepository;
    
    @Inject
    private EventoRepository eventoRepository;

    @Inject
    private ParticipanteMapper participanteMapper;

    /**
     * Save a participante.
     *
     * @param participanteDTO the entity to save
     * @return the persisted entity
     */
    public ParticipanteDTO save(ParticipanteDTO participanteDTO) {
        log.debug("Request to save Participante : {}", participanteDTO);
        Participante participante = participanteMapper.participanteDTOToParticipante(participanteDTO);
        participante = participanteRepository.save(participante);
        ParticipanteDTO result = participanteMapper.participanteToParticipanteDTO(participante);
        return result;
    }

    /**
     *  Get all the participantes.
     *  
     *  @param pageable the pagination information
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public Page<ParticipanteDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Participantes");
        Page<Participante> result = participanteRepository.findAll(pageable);
        return result.map(participante -> participanteMapper.participanteToParticipanteDTO(participante));
    }

    /**
     *  Get one participante by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ParticipanteDTO findOne(Long id) {
        log.debug("Request to get Participante : {}", id);
        Participante participante = participanteRepository.findOne(id);
        ParticipanteDTO participanteDTO = participanteMapper.participanteToParticipanteDTO(participante);
        return participanteDTO;
    }

    /**
     *  Delete the  participante by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Participante : {}", id);
        participanteRepository.delete(id);
    }

	@Override
	public List<ParticipanteDTO> registaParticipante(Long evento, String nome, double odd_vencer, String equipa,
			String pais) {
		
		List<ParticipanteDTO> listaParticipante = new ArrayList<ParticipanteDTO>();
		
		Evento eventoPart = eventoRepository.findEventoById(evento);
		
		Participante novoPart = new Participante();
		novoPart.setEvento(eventoPart);
		novoPart.setEquipa(equipa);
		novoPart.setNome(nome);
		novoPart.setOdd_vencer(odd_vencer);
		novoPart.setPais(pais);
		participanteRepository.saveAndFlush(novoPart);
		
		List<Participante> listaPart = participanteRepository.findAllByEvento(eventoPart);
		listaParticipante = participanteMapper.participantesToParticipanteDTOs(listaPart);
		
		return listaParticipante;
	}

	@Override
	public List<ParticipanteDTO> apagaParticipante(Long id) {
		List<ParticipanteDTO> listaParticipante = new ArrayList<ParticipanteDTO>();
		
		Participante participante = participanteRepository.findParticipanteById(id);
		Evento eventoPart = eventoRepository.findEventoById(participante.getEvento().getId());
		
		participanteRepository.delete(participante);
		
		List<Participante> listaPart = participanteRepository.findAllByEvento(eventoPart);
		listaParticipante = participanteMapper.participantesToParticipanteDTOs(listaPart);
		
		return listaParticipante;
	}

	@Override
	public List<ParticipanteDTO> eventoParticipantes(Long id) {
		List<ParticipanteDTO> listaParticipante = new ArrayList<ParticipanteDTO>();
		Evento eventoPart = eventoRepository.findEventoById(id);
		
		List<Participante> listaPart = participanteRepository.findAllByEvento(eventoPart);
		listaParticipante = participanteMapper.participantesToParticipanteDTOs(listaPart);
		
		return listaParticipante;
	}
	
	public List<ParticipanteDTO> updateParticipante(Long id ,Long evento, String nome, double odd_vencer, String equipa,
			String pais) {
		List<ParticipanteDTO> listaParticipante = new ArrayList<ParticipanteDTO>();
		
		Evento eventoPart = eventoRepository.findEventoById(evento);
		
		Participante participante = new Participante();
		participante =  participanteRepository.findParticipanteById(id);
		
		participante.setEvento(eventoPart);
		participante.setEquipa(equipa);
		participante.setNome(nome);
		participante.setOdd_vencer(odd_vencer);
		participante.setPais(pais);
		
		participanteRepository.saveAndFlush(participante);
		
		List<Participante> listaPart = participanteRepository.findAllByEvento(eventoPart);
		listaParticipante = participanteMapper.participantesToParticipanteDTOs(listaPart);
		
		return listaParticipante;
		
		
	}
	
}
