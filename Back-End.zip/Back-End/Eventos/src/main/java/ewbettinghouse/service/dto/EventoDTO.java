package ewbettinghouse.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Evento entity.
 */
public class EventoDTO implements Serializable {

    private Long id;

    private Integer n_participante;

    @NotNull
    private String estado;

    private String vencedor;

    private Boolean evento_equipa;

    @NotNull
    private Double odd_empate;

    private String desporto;

    @NotNull
    private Boolean publico;

    @NotNull
    private String horaInicio;

    @NotNull
    private String horaFim;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Integer getn_participante() {
        return n_participante;
    }

    public void setn_participante(Integer n_participante) {
        this.n_participante = n_participante;
    }
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    public String getVencedor() {
        return vencedor;
    }

    public void setVencedor(String vencedor) {
        this.vencedor = vencedor;
    }
    public Boolean getEvento_equipa() {
        return evento_equipa;
    }

    public void setEvento_equipa(Boolean evento_equipa) {
        this.evento_equipa = evento_equipa;
    }
    public Double getOdd_empate() {
        return odd_empate;
    }

    public void setOdd_empate(Double odd_empate) {
        this.odd_empate = odd_empate;
    }
    public String getDesporto() {
        return desporto;
    }

    public void setDesporto(String desporto) {
        this.desporto = desporto;
    }
    public Boolean getPublico() {
        return publico;
    }

    public void setPublico(Boolean publico) {
        this.publico = publico;
    }
    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }
    public String getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(String horaFim) {
        this.horaFim = horaFim;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        EventoDTO eventoDTO = (EventoDTO) o;

        if ( ! Objects.equals(id, eventoDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "EventoDTO{" +
            "id=" + id +
            ", n_participante='" + n_participante + "'" +
            ", estado='" + estado + "'" +
            ", vencedor='" + vencedor + "'" +
            ", evento_equipa='" + evento_equipa + "'" +
            ", odd_empate='" + odd_empate + "'" +
            ", desporto='" + desporto + "'" +
            ", publico='" + publico + "'" +
            ", horaInicio='" + horaInicio + "'" +
            ", horaFim='" + horaFim + "'" +
            '}';
    }
}
