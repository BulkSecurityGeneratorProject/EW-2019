package ewbettinghouse.service;

import ewbettinghouse.service.dto.ParticipanteDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

/**
 * Service Interface for managing Participante.
 */
public interface ParticipanteService {

    /**
     * Save a participante.
     *
     * @param participanteDTO the entity to save
     * @return the persisted entity
     */
    ParticipanteDTO save(ParticipanteDTO participanteDTO);

    /**
     *  Get all the participantes.
     *  
     *  @param pageable the pagination information
     *  @return the list of entities
     */
    Page<ParticipanteDTO> findAll(Pageable pageable);

    /**
     *  Get the "id" participante.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    ParticipanteDTO findOne(Long id);

    /**
     *  Delete the "id" participante.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

	List<ParticipanteDTO> registaParticipante(Long evento, String nome, double odd_vencer, String equipa, String pais);

	List<ParticipanteDTO> apagaParticipante(Long id);

	List<ParticipanteDTO> eventoParticipantes(Long id);
}
