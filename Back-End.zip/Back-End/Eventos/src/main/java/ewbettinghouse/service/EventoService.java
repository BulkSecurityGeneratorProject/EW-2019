package ewbettinghouse.service;

import ewbettinghouse.service.dto.EventoDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.text.ParseException;
import java.util.List;

/**
 * Service Interface for managing Evento.
 */
public interface EventoService {

    /**
     * Save a evento.
     *
     * @param eventoDTO the entity to save
     * @return the persisted entity
     */
    EventoDTO save(EventoDTO eventoDTO);

    /**
     *  Get all the eventos.
     *  
     *  @param pageable the pagination information
     *  @return the list of entities
     */
    Page<EventoDTO> findAll(Pageable pageable);

    /**
     *  Get the "id" evento.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    EventoDTO findOne(Long id);

    /**
     *  Delete the "id" evento.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

	EventoDTO adicionaEvento(String horaInicio, String horaFim, int n_participantes, String estado,
			String vencedor, boolean evento_equipa, double odd_empate, String desporto, boolean publico);

	List<EventoDTO> apagaEvento(Long id);

	List<EventoDTO> vencedorEvento(Long id, String vencedor);

	List<EventoDTO> estadoEvento(Long id, String estado);

	List<EventoDTO> todosEventos();

	List<EventoDTO> abertosEventos();

	List<EventoDTO> publicosEventos();

	List<EventoDTO> privadosEventos();

	List<EventoDTO> fecharamRecetemente() throws ParseException;

	List<EventoDTO> fechadosEventos();

	List<EventoDTO> updateEvento(Long id, String horaInicio, String horaFim, int n_participantes, String estado,
			String vencedor, boolean evento_equipa, double odd_empate, String desporto, boolean publico);

	List<EventoDTO> fechaEventos() throws ParseException;
}
