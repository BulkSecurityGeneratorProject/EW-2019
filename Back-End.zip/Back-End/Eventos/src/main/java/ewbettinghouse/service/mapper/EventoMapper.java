package ewbettinghouse.service.mapper;

import ewbettinghouse.domain.*;
import ewbettinghouse.service.dto.EventoDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Evento and its DTO EventoDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface EventoMapper {

    EventoDTO eventoToEventoDTO(Evento evento);

    List<EventoDTO> eventosToEventoDTOs(List<Evento> eventos);

    @Mapping(target = "participantes", ignore = true)
    Evento eventoDTOToEvento(EventoDTO eventoDTO);

    List<Evento> eventoDTOsToEventos(List<EventoDTO> eventoDTOs);
}
