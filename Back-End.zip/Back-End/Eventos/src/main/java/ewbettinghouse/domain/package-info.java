/**
 * JPA domain objects.
 */
package ewbettinghouse.domain;
