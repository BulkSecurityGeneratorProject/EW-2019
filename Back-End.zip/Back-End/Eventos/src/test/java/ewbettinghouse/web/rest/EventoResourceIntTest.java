package ewbettinghouse.web.rest;

import ewbettinghouse.Ew2019EventosApp;

import ewbettinghouse.domain.Evento;
import ewbettinghouse.repository.EventoRepository;
import ewbettinghouse.service.EventoService;
import ewbettinghouse.service.dto.EventoDTO;
import ewbettinghouse.service.mapper.EventoMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the EventoResource REST controller.
 *
 * @see EventoResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Ew2019EventosApp.class)
public class EventoResourceIntTest {

    private static final Integer DEFAULT_N_PARTICIPANTE = 1;
    private static final Integer UPDATED_N_PARTICIPANTE = 2;

    private static final String DEFAULT_ESTADO = "AAAAAAAAAA";
    private static final String UPDATED_ESTADO = "BBBBBBBBBB";

    private static final String DEFAULT_VENCEDOR = "AAAAAAAAAA";
    private static final String UPDATED_VENCEDOR = "BBBBBBBBBB";

    private static final Boolean DEFAULT_EVENTO_EQUIPA = false;
    private static final Boolean UPDATED_EVENTO_EQUIPA = true;

    private static final Double DEFAULT_ODD_EMPATE = 1D;
    private static final Double UPDATED_ODD_EMPATE = 2D;

    private static final String DEFAULT_DESPORTO = "AAAAAAAAAA";
    private static final String UPDATED_DESPORTO = "BBBBBBBBBB";

    private static final Boolean DEFAULT_PUBLICO = false;
    private static final Boolean UPDATED_PUBLICO = true;

    private static final String DEFAULT_HORA_INICIO = "AAAAAAAAAA";
    private static final String UPDATED_HORA_INICIO = "BBBBBBBBBB";

    private static final String DEFAULT_HORA_FIM = "AAAAAAAAAA";
    private static final String UPDATED_HORA_FIM = "BBBBBBBBBB";

    @Inject
    private EventoRepository eventoRepository;

    @Inject
    private EventoMapper eventoMapper;

    @Inject
    private EventoService eventoService;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restEventoMockMvc;

    private Evento evento;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        EventoResource eventoResource = new EventoResource();
        ReflectionTestUtils.setField(eventoResource, "eventoService", eventoService);
        this.restEventoMockMvc = MockMvcBuilders.standaloneSetup(eventoResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Evento createEntity(EntityManager em) {
        Evento evento = new Evento()
                .n_participante(DEFAULT_N_PARTICIPANTE)
                .estado(DEFAULT_ESTADO)
                .vencedor(DEFAULT_VENCEDOR)
                .evento_equipa(DEFAULT_EVENTO_EQUIPA)
                .odd_empate(DEFAULT_ODD_EMPATE)
                .desporto(DEFAULT_DESPORTO)
                .publico(DEFAULT_PUBLICO)
                .horaInicio(DEFAULT_HORA_INICIO)
                .horaFim(DEFAULT_HORA_FIM);
        return evento;
    }

    @Before
    public void initTest() {
        evento = createEntity(em);
    }

    @Test
    @Transactional
    public void createEvento() throws Exception {
        int databaseSizeBeforeCreate = eventoRepository.findAll().size();

        // Create the Evento
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);

        restEventoMockMvc.perform(post("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isCreated());

        // Validate the Evento in the database
        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeCreate + 1);
        Evento testEvento = eventoList.get(eventoList.size() - 1);
        assertThat(testEvento.getn_participante()).isEqualTo(DEFAULT_N_PARTICIPANTE);
        assertThat(testEvento.getEstado()).isEqualTo(DEFAULT_ESTADO);
        assertThat(testEvento.getVencedor()).isEqualTo(DEFAULT_VENCEDOR);
        assertThat(testEvento.isEvento_equipa()).isEqualTo(DEFAULT_EVENTO_EQUIPA);
        assertThat(testEvento.getOdd_empate()).isEqualTo(DEFAULT_ODD_EMPATE);
        assertThat(testEvento.getDesporto()).isEqualTo(DEFAULT_DESPORTO);
        assertThat(testEvento.isPublico()).isEqualTo(DEFAULT_PUBLICO);
        assertThat(testEvento.getHoraInicio()).isEqualTo(DEFAULT_HORA_INICIO);
        assertThat(testEvento.getHoraFim()).isEqualTo(DEFAULT_HORA_FIM);
    }

    @Test
    @Transactional
    public void createEventoWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = eventoRepository.findAll().size();

        // Create the Evento with an existing ID
        Evento existingEvento = new Evento();
        existingEvento.setId(1L);
        EventoDTO existingEventoDTO = eventoMapper.eventoToEventoDTO(existingEvento);

        // An entity with an existing ID cannot be created, so this API call must fail
        restEventoMockMvc.perform(post("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(existingEventoDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Alice in the database
        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkEstadoIsRequired() throws Exception {
        int databaseSizeBeforeTest = eventoRepository.findAll().size();
        // set the field null
        evento.setEstado(null);

        // Create the Evento, which fails.
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);

        restEventoMockMvc.perform(post("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isBadRequest());

        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkOdd_empateIsRequired() throws Exception {
        int databaseSizeBeforeTest = eventoRepository.findAll().size();
        // set the field null
        evento.setOdd_empate(null);

        // Create the Evento, which fails.
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);

        restEventoMockMvc.perform(post("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isBadRequest());

        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkPublicoIsRequired() throws Exception {
        int databaseSizeBeforeTest = eventoRepository.findAll().size();
        // set the field null
        evento.setPublico(null);

        // Create the Evento, which fails.
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);

        restEventoMockMvc.perform(post("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isBadRequest());

        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkHoraInicioIsRequired() throws Exception {
        int databaseSizeBeforeTest = eventoRepository.findAll().size();
        // set the field null
        evento.setHoraInicio(null);

        // Create the Evento, which fails.
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);

        restEventoMockMvc.perform(post("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isBadRequest());

        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkHoraFimIsRequired() throws Exception {
        int databaseSizeBeforeTest = eventoRepository.findAll().size();
        // set the field null
        evento.setHoraFim(null);

        // Create the Evento, which fails.
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);

        restEventoMockMvc.perform(post("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isBadRequest());

        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllEventos() throws Exception {
        // Initialize the database
        eventoRepository.saveAndFlush(evento);

        // Get all the eventoList
        restEventoMockMvc.perform(get("/api/eventos?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(evento.getId().intValue())))
            .andExpect(jsonPath("$.[*].n_participante").value(hasItem(DEFAULT_N_PARTICIPANTE)))
            .andExpect(jsonPath("$.[*].estado").value(hasItem(DEFAULT_ESTADO.toString())))
            .andExpect(jsonPath("$.[*].vencedor").value(hasItem(DEFAULT_VENCEDOR.toString())))
            .andExpect(jsonPath("$.[*].evento_equipa").value(hasItem(DEFAULT_EVENTO_EQUIPA.booleanValue())))
            .andExpect(jsonPath("$.[*].odd_empate").value(hasItem(DEFAULT_ODD_EMPATE.doubleValue())))
            .andExpect(jsonPath("$.[*].desporto").value(hasItem(DEFAULT_DESPORTO.toString())))
            .andExpect(jsonPath("$.[*].publico").value(hasItem(DEFAULT_PUBLICO.booleanValue())))
            .andExpect(jsonPath("$.[*].horaInicio").value(hasItem(DEFAULT_HORA_INICIO.toString())))
            .andExpect(jsonPath("$.[*].horaFim").value(hasItem(DEFAULT_HORA_FIM.toString())));
    }

    @Test
    @Transactional
    public void getEvento() throws Exception {
        // Initialize the database
        eventoRepository.saveAndFlush(evento);

        // Get the evento
        restEventoMockMvc.perform(get("/api/eventos/{id}", evento.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(evento.getId().intValue()))
            .andExpect(jsonPath("$.n_participante").value(DEFAULT_N_PARTICIPANTE))
            .andExpect(jsonPath("$.estado").value(DEFAULT_ESTADO.toString()))
            .andExpect(jsonPath("$.vencedor").value(DEFAULT_VENCEDOR.toString()))
            .andExpect(jsonPath("$.evento_equipa").value(DEFAULT_EVENTO_EQUIPA.booleanValue()))
            .andExpect(jsonPath("$.odd_empate").value(DEFAULT_ODD_EMPATE.doubleValue()))
            .andExpect(jsonPath("$.desporto").value(DEFAULT_DESPORTO.toString()))
            .andExpect(jsonPath("$.publico").value(DEFAULT_PUBLICO.booleanValue()))
            .andExpect(jsonPath("$.horaInicio").value(DEFAULT_HORA_INICIO.toString()))
            .andExpect(jsonPath("$.horaFim").value(DEFAULT_HORA_FIM.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingEvento() throws Exception {
        // Get the evento
        restEventoMockMvc.perform(get("/api/eventos/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateEvento() throws Exception {
        // Initialize the database
        eventoRepository.saveAndFlush(evento);
        int databaseSizeBeforeUpdate = eventoRepository.findAll().size();

        // Update the evento
        Evento updatedEvento = eventoRepository.findOne(evento.getId());
        updatedEvento
                .n_participante(UPDATED_N_PARTICIPANTE)
                .estado(UPDATED_ESTADO)
                .vencedor(UPDATED_VENCEDOR)
                .evento_equipa(UPDATED_EVENTO_EQUIPA)
                .odd_empate(UPDATED_ODD_EMPATE)
                .desporto(UPDATED_DESPORTO)
                .publico(UPDATED_PUBLICO)
                .horaInicio(UPDATED_HORA_INICIO)
                .horaFim(UPDATED_HORA_FIM);
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(updatedEvento);

        restEventoMockMvc.perform(put("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isOk());

        // Validate the Evento in the database
        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeUpdate);
        Evento testEvento = eventoList.get(eventoList.size() - 1);
        assertThat(testEvento.getn_participante()).isEqualTo(UPDATED_N_PARTICIPANTE);
        assertThat(testEvento.getEstado()).isEqualTo(UPDATED_ESTADO);
        assertThat(testEvento.getVencedor()).isEqualTo(UPDATED_VENCEDOR);
        assertThat(testEvento.isEvento_equipa()).isEqualTo(UPDATED_EVENTO_EQUIPA);
        assertThat(testEvento.getOdd_empate()).isEqualTo(UPDATED_ODD_EMPATE);
        assertThat(testEvento.getDesporto()).isEqualTo(UPDATED_DESPORTO);
        assertThat(testEvento.isPublico()).isEqualTo(UPDATED_PUBLICO);
        assertThat(testEvento.getHoraInicio()).isEqualTo(UPDATED_HORA_INICIO);
        assertThat(testEvento.getHoraFim()).isEqualTo(UPDATED_HORA_FIM);
    }

    @Test
    @Transactional
    public void updateNonExistingEvento() throws Exception {
        int databaseSizeBeforeUpdate = eventoRepository.findAll().size();

        // Create the Evento
        EventoDTO eventoDTO = eventoMapper.eventoToEventoDTO(evento);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restEventoMockMvc.perform(put("/api/eventos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(eventoDTO)))
            .andExpect(status().isCreated());

        // Validate the Evento in the database
        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteEvento() throws Exception {
        // Initialize the database
        eventoRepository.saveAndFlush(evento);
        int databaseSizeBeforeDelete = eventoRepository.findAll().size();

        // Get the evento
        restEventoMockMvc.perform(delete("/api/eventos/{id}", evento.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Evento> eventoList = eventoRepository.findAll();
        assertThat(eventoList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
