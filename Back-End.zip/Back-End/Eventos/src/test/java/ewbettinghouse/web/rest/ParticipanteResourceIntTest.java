package ewbettinghouse.web.rest;

import ewbettinghouse.Ew2019EventosApp;

import ewbettinghouse.domain.Participante;
import ewbettinghouse.repository.ParticipanteRepository;
import ewbettinghouse.service.ParticipanteService;
import ewbettinghouse.service.dto.ParticipanteDTO;
import ewbettinghouse.service.mapper.ParticipanteMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ParticipanteResource REST controller.
 *
 * @see ParticipanteResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Ew2019EventosApp.class)
public class ParticipanteResourceIntTest {

    private static final String DEFAULT_NOME = "AAAAAAAAAA";
    private static final String UPDATED_NOME = "BBBBBBBBBB";

    private static final Double DEFAULT_ODD_VENCER = 1D;
    private static final Double UPDATED_ODD_VENCER = 2D;

    private static final String DEFAULT_EQUIPA = "AAAAAAAAAA";
    private static final String UPDATED_EQUIPA = "BBBBBBBBBB";

    private static final String DEFAULT_PAIS = "AAAAAAAAAA";
    private static final String UPDATED_PAIS = "BBBBBBBBBB";

    @Inject
    private ParticipanteRepository participanteRepository;

    @Inject
    private ParticipanteMapper participanteMapper;

    @Inject
    private ParticipanteService participanteService;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restParticipanteMockMvc;

    private Participante participante;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ParticipanteResource participanteResource = new ParticipanteResource();
        ReflectionTestUtils.setField(participanteResource, "participanteService", participanteService);
        this.restParticipanteMockMvc = MockMvcBuilders.standaloneSetup(participanteResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Participante createEntity(EntityManager em) {
        Participante participante = new Participante()
                .nome(DEFAULT_NOME)
                .odd_vencer(DEFAULT_ODD_VENCER)
                .equipa(DEFAULT_EQUIPA)
                .pais(DEFAULT_PAIS);
        return participante;
    }

    @Before
    public void initTest() {
        participante = createEntity(em);
    }

    @Test
    @Transactional
    public void createParticipante() throws Exception {
        int databaseSizeBeforeCreate = participanteRepository.findAll().size();

        // Create the Participante
        ParticipanteDTO participanteDTO = participanteMapper.participanteToParticipanteDTO(participante);

        restParticipanteMockMvc.perform(post("/api/participantes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(participanteDTO)))
            .andExpect(status().isCreated());

        // Validate the Participante in the database
        List<Participante> participanteList = participanteRepository.findAll();
        assertThat(participanteList).hasSize(databaseSizeBeforeCreate + 1);
        Participante testParticipante = participanteList.get(participanteList.size() - 1);
        assertThat(testParticipante.getNome()).isEqualTo(DEFAULT_NOME);
        assertThat(testParticipante.getOdd_vencer()).isEqualTo(DEFAULT_ODD_VENCER);
        assertThat(testParticipante.getEquipa()).isEqualTo(DEFAULT_EQUIPA);
        assertThat(testParticipante.getPais()).isEqualTo(DEFAULT_PAIS);
    }

    @Test
    @Transactional
    public void createParticipanteWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = participanteRepository.findAll().size();

        // Create the Participante with an existing ID
        Participante existingParticipante = new Participante();
        existingParticipante.setId(1L);
        ParticipanteDTO existingParticipanteDTO = participanteMapper.participanteToParticipanteDTO(existingParticipante);

        // An entity with an existing ID cannot be created, so this API call must fail
        restParticipanteMockMvc.perform(post("/api/participantes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(existingParticipanteDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Alice in the database
        List<Participante> participanteList = participanteRepository.findAll();
        assertThat(participanteList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkNomeIsRequired() throws Exception {
        int databaseSizeBeforeTest = participanteRepository.findAll().size();
        // set the field null
        participante.setNome(null);

        // Create the Participante, which fails.
        ParticipanteDTO participanteDTO = participanteMapper.participanteToParticipanteDTO(participante);

        restParticipanteMockMvc.perform(post("/api/participantes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(participanteDTO)))
            .andExpect(status().isBadRequest());

        List<Participante> participanteList = participanteRepository.findAll();
        assertThat(participanteList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkOdd_vencerIsRequired() throws Exception {
        int databaseSizeBeforeTest = participanteRepository.findAll().size();
        // set the field null
        participante.setOdd_vencer(null);

        // Create the Participante, which fails.
        ParticipanteDTO participanteDTO = participanteMapper.participanteToParticipanteDTO(participante);

        restParticipanteMockMvc.perform(post("/api/participantes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(participanteDTO)))
            .andExpect(status().isBadRequest());

        List<Participante> participanteList = participanteRepository.findAll();
        assertThat(participanteList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllParticipantes() throws Exception {
        // Initialize the database
        participanteRepository.saveAndFlush(participante);

        // Get all the participanteList
        restParticipanteMockMvc.perform(get("/api/participantes?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(participante.getId().intValue())))
            .andExpect(jsonPath("$.[*].nome").value(hasItem(DEFAULT_NOME.toString())))
            .andExpect(jsonPath("$.[*].odd_vencer").value(hasItem(DEFAULT_ODD_VENCER.doubleValue())))
            .andExpect(jsonPath("$.[*].equipa").value(hasItem(DEFAULT_EQUIPA.toString())))
            .andExpect(jsonPath("$.[*].pais").value(hasItem(DEFAULT_PAIS.toString())));
    }

    @Test
    @Transactional
    public void getParticipante() throws Exception {
        // Initialize the database
        participanteRepository.saveAndFlush(participante);

        // Get the participante
        restParticipanteMockMvc.perform(get("/api/participantes/{id}", participante.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(participante.getId().intValue()))
            .andExpect(jsonPath("$.nome").value(DEFAULT_NOME.toString()))
            .andExpect(jsonPath("$.odd_vencer").value(DEFAULT_ODD_VENCER.doubleValue()))
            .andExpect(jsonPath("$.equipa").value(DEFAULT_EQUIPA.toString()))
            .andExpect(jsonPath("$.pais").value(DEFAULT_PAIS.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingParticipante() throws Exception {
        // Get the participante
        restParticipanteMockMvc.perform(get("/api/participantes/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateParticipante() throws Exception {
        // Initialize the database
        participanteRepository.saveAndFlush(participante);
        int databaseSizeBeforeUpdate = participanteRepository.findAll().size();

        // Update the participante
        Participante updatedParticipante = participanteRepository.findOne(participante.getId());
        updatedParticipante
                .nome(UPDATED_NOME)
                .odd_vencer(UPDATED_ODD_VENCER)
                .equipa(UPDATED_EQUIPA)
                .pais(UPDATED_PAIS);
        ParticipanteDTO participanteDTO = participanteMapper.participanteToParticipanteDTO(updatedParticipante);

        restParticipanteMockMvc.perform(put("/api/participantes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(participanteDTO)))
            .andExpect(status().isOk());

        // Validate the Participante in the database
        List<Participante> participanteList = participanteRepository.findAll();
        assertThat(participanteList).hasSize(databaseSizeBeforeUpdate);
        Participante testParticipante = participanteList.get(participanteList.size() - 1);
        assertThat(testParticipante.getNome()).isEqualTo(UPDATED_NOME);
        assertThat(testParticipante.getOdd_vencer()).isEqualTo(UPDATED_ODD_VENCER);
        assertThat(testParticipante.getEquipa()).isEqualTo(UPDATED_EQUIPA);
        assertThat(testParticipante.getPais()).isEqualTo(UPDATED_PAIS);
    }

    @Test
    @Transactional
    public void updateNonExistingParticipante() throws Exception {
        int databaseSizeBeforeUpdate = participanteRepository.findAll().size();

        // Create the Participante
        ParticipanteDTO participanteDTO = participanteMapper.participanteToParticipanteDTO(participante);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restParticipanteMockMvc.perform(put("/api/participantes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(participanteDTO)))
            .andExpect(status().isCreated());

        // Validate the Participante in the database
        List<Participante> participanteList = participanteRepository.findAll();
        assertThat(participanteList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteParticipante() throws Exception {
        // Initialize the database
        participanteRepository.saveAndFlush(participante);
        int databaseSizeBeforeDelete = participanteRepository.findAll().size();

        // Get the participante
        restParticipanteMockMvc.perform(delete("/api/participantes/{id}", participante.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Participante> participanteList = participanteRepository.findAll();
        assertThat(participanteList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
