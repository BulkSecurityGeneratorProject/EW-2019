package ewweb.repository.search;

import ewweb.domain.Aposta;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the Aposta entity.
 */
public interface ApostaSearchRepository extends ElasticsearchRepository<Aposta, Long> {
}
