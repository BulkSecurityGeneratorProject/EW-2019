/**
 * Spring Data JPA repositories.
 */
package ewweb.repository;
