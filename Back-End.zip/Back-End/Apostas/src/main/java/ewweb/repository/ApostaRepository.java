package ewweb.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import ewweb.domain.Aposta;

/**
 * Spring Data JPA repository for the Aposta entity.
 */
@SuppressWarnings("unused")
public interface ApostaRepository extends JpaRepository<Aposta,Long> {

	List<Aposta> findByUtilizadorAndEstado(@Param("utilizador") Integer utilizador, @Param("estado") String estado);

	Aposta findByid(@Param("aposta")Long aposta);

	List<Aposta> findByEstado(@Param("estado") String estado);

	List<Aposta> findAllByUtilizador(@Param("utilizador") Integer id);

	List<Aposta> findAllByEvento(@Param("evento") Integer id);
	
	List<Aposta> findByEventoAndEstado(@Param("evento") Integer utilizador, @Param("estado") String estado);

	

}
