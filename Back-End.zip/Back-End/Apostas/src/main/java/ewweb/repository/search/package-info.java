/**
 * Spring Data ElasticSearch repositories.
 */
package ewweb.repository.search;
