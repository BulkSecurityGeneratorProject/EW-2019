/**
 * View Models used by Spring MVC REST controllers.
 */
package ewweb.web.rest.vm;
