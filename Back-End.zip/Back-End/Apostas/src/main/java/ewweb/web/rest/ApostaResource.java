package ewweb.web.rest;

import com.codahale.metrics.annotation.Timed;
import ewweb.service.ApostaService;
import ewweb.web.rest.util.HeaderUtil;
import ewweb.service.dto.ApostaDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing Aposta.
 */
@RestController
@RequestMapping("/api")
public class ApostaResource {

    private final Logger log = LoggerFactory.getLogger(ApostaResource.class);
        
    @Inject
    private ApostaService apostaService;

    /**
     * POST  /apostas : Create a new aposta.
     *
     * @param apostaDTO the apostaDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new apostaDTO, or with status 400 (Bad Request) if the aposta has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/apostas")
    @Timed
    public ResponseEntity<ApostaDTO> createAposta(@Valid @RequestBody ApostaDTO apostaDTO) throws URISyntaxException {
        log.debug("REST request to save Aposta : {}", apostaDTO);
        if (apostaDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("aposta", "idexists", "A new aposta cannot already have an ID")).body(null);
        }
        ApostaDTO result = apostaService.save(apostaDTO);
        return ResponseEntity.created(new URI("/api/apostas/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("aposta", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /apostas : Updates an existing aposta.
     *
     * @param apostaDTO the apostaDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated apostaDTO,
     * or with status 400 (Bad Request) if the apostaDTO is not valid,
     * or with status 500 (Internal Server Error) if the apostaDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/apostas")
    @Timed
    public ResponseEntity<ApostaDTO> updateAposta(@Valid @RequestBody ApostaDTO apostaDTO) throws URISyntaxException {
        log.debug("REST request to update Aposta : {}", apostaDTO);
        if (apostaDTO.getId() == null) {
            return createAposta(apostaDTO);
        }
        ApostaDTO result = apostaService.save(apostaDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("aposta", apostaDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /apostas : get all the apostas.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of apostas in body
     */
    @GetMapping("/apostas")
    @Timed
    public List<ApostaDTO> getAllApostas() {
        log.debug("REST request to get all Apostas");
        return apostaService.findAll();
    }

    /**
     * GET  /apostas/:id : get the "id" aposta.
     *
     * @param id the id of the apostaDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the apostaDTO, or with status 404 (Not Found)
     */
    @GetMapping("/apostas/{id}")
    @Timed
    public ResponseEntity<ApostaDTO> getAposta(@PathVariable Long id) {
        log.debug("REST request to get Aposta : {}", id);
        ApostaDTO apostaDTO = apostaService.findOne(id);
        return Optional.ofNullable(apostaDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /apostas/:id : delete the "id" aposta.
     *
     * @param id the id of the apostaDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/apostas/{id}")
    @Timed
    public ResponseEntity<Void> deleteAposta(@PathVariable Long id) {
        log.debug("REST request to delete Aposta : {}", id);
        apostaService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("aposta", id.toString())).build();
    }

    /**
     * SEARCH  /_search/apostas?query=:query : search for the aposta corresponding
     * to the query.
     *
     * @param query the query of the aposta search 
     * @return the result of the search
     */
    @GetMapping("/_search/apostas")
    @Timed
    public List<ApostaDTO> searchApostas(@RequestParam String query) {
        log.debug("REST request to search Apostas for query {}", query);
        return apostaService.search(query);
    }


}
