package ewweb.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import ewweb.domain.Evento;
import ewweb.domain.Participante;
import ewweb.domain.Utilizador;
import ewweb.service.ApostaService;
import ewweb.web.rest.util.HeaderUtil;
import ewweb.service.dto.ApostaDTO;
import ewweb.service.dto.InfoApostaDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing Aposta.
 */
@RestController
@RequestMapping("/api")
public class ApostaResource {

    private final Logger log = LoggerFactory.getLogger(ApostaResource.class);
        
    @Inject
    private ApostaService apostaService;

    /**
     * POST  /apostas : Create a new aposta.
     *
     * @param apostaDTO the apostaDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new apostaDTO, or with status 400 (Bad Request) if the aposta has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/apostas")
    @Timed
    public ResponseEntity<ApostaDTO> createAposta(@Valid @RequestBody ApostaDTO apostaDTO) throws URISyntaxException {
        log.debug("REST request to save Aposta : {}", apostaDTO);
        if (apostaDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("aposta", "idexists", "A new aposta cannot already have an ID")).body(null);
        }
        ApostaDTO result = apostaService.save(apostaDTO);
        return ResponseEntity.created(new URI("/api/apostas/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("aposta", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /apostas : Updates an existing aposta.
     *
     * @param apostaDTO the apostaDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated apostaDTO,
     * or with status 400 (Bad Request) if the apostaDTO is not valid,
     * or with status 500 (Internal Server Error) if the apostaDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/apostas")
    @Timed
    public ResponseEntity<ApostaDTO> updateAposta(@Valid @RequestBody ApostaDTO apostaDTO) throws URISyntaxException {
        log.debug("REST request to update Aposta : {}", apostaDTO);
        if (apostaDTO.getId() == null) {
            return createAposta(apostaDTO);
        }
        ApostaDTO result = apostaService.save(apostaDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("aposta", apostaDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /apostas : get all the apostas.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of apostas in body
     */
    @GetMapping("/apostas")
    @Timed
    public List<ApostaDTO> getAllApostas() {
        log.debug("REST request to get all Apostas");
        return apostaService.findAll();
    }

    /**
     * GET  /apostas/:id : get the "id" aposta.
     *
     * @param id the id of the apostaDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the apostaDTO, or with status 404 (Not Found)
     */
    @GetMapping("/apostas/{id}")
    @Timed
    public ResponseEntity<ApostaDTO> getAposta(@PathVariable Long id) {
        log.debug("REST request to get Aposta : {}", id);
        ApostaDTO apostaDTO = apostaService.findOne(id);
        return Optional.ofNullable(apostaDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /apostas/:id : delete the "id" aposta.
     *
     * @param id the id of the apostaDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/apostas/{id}")
    @Timed
    public ResponseEntity<Void> deleteAposta(@PathVariable Long id) {
        log.debug("REST request to delete Aposta : {}", id);
        apostaService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("aposta", id.toString())).build();
    }

    /**
     * SEARCH  /_search/apostas?query=:query : search for the aposta corresponding
     * to the query.
     *
     * @param query the query of the aposta search 
     * @return the result of the search
     */
    @GetMapping("/_search/apostas")
    @Timed
    public List<ApostaDTO> searchApostas(@RequestParam String query) {
        log.debug("REST request to search Apostas for query {}", query);
        return apostaService.search(query);
    }
    
    @GetMapping("apostas/{utilizador}/{evento}/{participante}")
    @Timed
    public ResponseEntity<List <InfoApostaDTO>> utilizadorApostas(@PathVariable Long utilizador, @PathVariable Long evento,  @PathVariable Long participante) {
    	List<InfoApostaDTO> listaApostas = new  ArrayList<InfoApostaDTO>();
    	
    	//Info do utilizador do microservico dos utilizadores
    			Utilizador utilizadorInfo = new Utilizador();
    			String URLUser = "http://localhost:8082/api/utilizador/" + String.valueOf(utilizador);
    			utilizadorInfo =  new RestTemplate().getForObject(URLUser, Utilizador.class);
    			System.out.println(utilizadorInfo);
    			
    			//Info do evento do microservico dos eventos
    			Evento eventoInfo = new Evento();
    			String URLEvento = "http://localhost:8081/api/eventos/" + String.valueOf(evento);
    			eventoInfo = new RestTemplate().getForObject(URLEvento, Evento.class);
    			System.out.println(eventoInfo);
    			
    			//Info dos participantes do microservico dos eventos
    			Participante partipantesInfo = new Participante();
    			String URLParticipantes = "http://localhost:8081/api/participantes/" + String.valueOf(participante);
    			partipantesInfo = new RestTemplate().getForObject(URLParticipantes, Participante.class);
    			System.out.println(partipantesInfo);
    			
    			List<Participante> partipantesTodosInfo = new ArrayList<Participante>();
    			String URLParticipantesTodos = "http://localhost:8081/api/participantes/evento/" + String.valueOf(evento);
    			partipantesTodosInfo = new RestTemplate().getForObject(URLParticipantesTodos, ArrayList.class);
    			System.out.println(partipantesTodosInfo);
    			
    			
    	 
    	 try {
    		listaApostas = apostaService.utilizadorApostas(utilizadorInfo, eventoInfo, partipantesInfo, partipantesTodosInfo);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    @GetMapping("apostas/novaAposta/{utilizador}/{evento}/{participante}/{montante}")
    @Timed
    public ResponseEntity<List<ApostaDTO>> novaAposta(@PathVariable Long utilizador, @PathVariable Long evento,  @PathVariable Long participante, 
    		@PathVariable Float montante) {
    	List<ApostaDTO> listaApostas = new  ArrayList<ApostaDTO>();
    	
    	 try {
    		listaApostas = apostaService.novaAposta(utilizador, evento, participante, montante);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }

    @GetMapping("apostas/novaApostaEmpate/{utilizador}/{evento}/{montante}")
    @Timed
    public ResponseEntity<List<ApostaDTO>> novaApostaEmpate(@PathVariable Long utilizador, @PathVariable Long evento, 
    		@PathVariable Float montante) {
    	List<ApostaDTO> listaApostas = new  ArrayList<ApostaDTO>();
    	
    	 try {
    		listaApostas = apostaService.novaApostaEmpate(utilizador, evento, montante);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    @GetMapping("apostas/eliminaAposta/{utilizador}/{aposta}")
    @Timed
    public ResponseEntity<List<ApostaDTO>> eliminaAposta(@PathVariable Long utilizador, @PathVariable Long aposta) {
    	List<ApostaDTO> listaApostas = new  ArrayList<ApostaDTO>();
    	
    	 try {
    		listaApostas = apostaService.eliminaAposta(utilizador, aposta);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    @GetMapping("apostas/fechaAposta/{utilizador}/{aposta}")
    @Timed
    public ResponseEntity<List<ApostaDTO>> fechaAposta(@PathVariable Long utilizador, @PathVariable Long aposta) {
    	List<ApostaDTO> listaApostas = new  ArrayList<ApostaDTO>();
    	
    	 try {
    		listaApostas = apostaService.fechaAposta(utilizador, aposta);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    // Devolve apostas abertas e as fechadas recentemente (até a 2 dias)
    @GetMapping("apostas/apostasAbertas/{utilizador}")
    @Timed
    public ResponseEntity<List <InfoApostaDTO>> utilizadorApostasAbertas(@PathVariable Long utilizador) {
    	List<InfoApostaDTO> listaApostas = new  ArrayList<InfoApostaDTO>();
    	
    	//Info do utilizador do microservico dos utilizadores
    			Utilizador utilizadorInfo = new Utilizador();
    			String URLUser = "http://localhost:8082/api/utilizador/" + String.valueOf(utilizador);
    			utilizadorInfo =  new RestTemplate().getForObject(URLUser, Utilizador.class);
    			System.out.println(utilizadorInfo);
    			
    			//Info do evento do microservico dos eventos
    			List<Evento> eventoInfo = new ArrayList<Evento>();
    			String URLEvento = "http://localhost:8081/api/eventos/fecharamRecetemente";
    			eventoInfo = new RestTemplate().getForObject(URLEvento, ArrayList.class);
    			System.out.println(eventoInfo);
    			
    			//Info dos participantes do microservico dos eventos
    			List<Participante> partipantesInfo = new ArrayList<Participante>();
    			String URLParticipantes = "http://localhost:8081/api/participantes/";
    			partipantesInfo = new RestTemplate().getForObject(URLParticipantes, ArrayList.class);
    			System.out.println(partipantesInfo);
    			
    		
    	 try {
    		listaApostas = apostaService.utilizadorApostasAbertas(utilizadorInfo, eventoInfo, partipantesInfo);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    // Devolve o historico de um utilizador 
    @GetMapping("apostas/historico/{utilizador}")
    @Timed
    public ResponseEntity<List <InfoApostaDTO>> historicoApostas(@PathVariable Long utilizador) {
    	List<InfoApostaDTO> listaApostas = new  ArrayList<InfoApostaDTO>();
    	
    	//Info do utilizador do microservico dos utilizadores
    			Utilizador utilizadorInfo = new Utilizador();
    			String URLUser = "http://localhost:8082/api/utilizador/" + String.valueOf(utilizador);
    			utilizadorInfo =  new RestTemplate().getForObject(URLUser, Utilizador.class);
    			System.out.println(utilizadorInfo);
    			
    			//Info do evento do microservico dos eventos
    			List<Evento> eventoInfo = new ArrayList<Evento>();
    			String URLEvento = "http://localhost:8081/api/eventos/fechados";
    			eventoInfo = new RestTemplate().getForObject(URLEvento, ArrayList.class);
    			System.out.println(eventoInfo);
    			
    			//Info dos participantes do microservico dos eventos
    			List<Participante> partipantesInfo = new ArrayList<Participante>();
    			String URLParticipantes = "http://localhost:8081/api/participantes/";
    			partipantesInfo = new RestTemplate().getForObject(URLParticipantes, ArrayList.class);
    			System.out.println(partipantesInfo);
    			
    		
    	 try {
    		listaApostas = apostaService.historicoApostas(utilizadorInfo, eventoInfo, partipantesInfo);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    //Todas as apostas abertas
    @GetMapping("apostas/todasAbertas")
    @Timed
    public ResponseEntity<List <InfoApostaDTO>> todasAbertasApostas() {
    	List<InfoApostaDTO> listaApostas = new  ArrayList<InfoApostaDTO>();
    	
    	//Info do utilizador do microservico dos utilizadores
    			List<Utilizador> utilizadorInfo = new ArrayList<Utilizador>();
    			String URLUser = "http://localhost:8082/api/utilizadors";
    			utilizadorInfo =  new RestTemplate().getForObject(URLUser, ArrayList.class);
    			System.out.println(utilizadorInfo);
    			
    			//Info do evento do microservico dos eventos
    			List<Evento> eventoInfo = new ArrayList<Evento>();
    			String URLEvento = "http://localhost:8081/api/eventos/abertos";
    			eventoInfo = new RestTemplate().getForObject(URLEvento, ArrayList.class);
    			System.out.println(eventoInfo);
    			
    			//Info dos participantes do microservico dos eventos
    			List<Participante> partipantesInfo = new ArrayList<Participante>();
    			String URLParticipantes = "http://localhost:8081/api/participantes/";
    			partipantesInfo = new RestTemplate().getForObject(URLParticipantes, ArrayList.class);
    			System.out.println(partipantesInfo);
    			
    		
    	 try {
    		listaApostas = apostaService.todasAbertasApostas(utilizadorInfo, eventoInfo, partipantesInfo);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    
    //Todas as apostas abertas e fechadas
    //Todas as apostas abertas
    @GetMapping("apostas/todasApostas")
    @Timed
    public ResponseEntity<List <InfoApostaDTO>> todasApostas() {
    	List<InfoApostaDTO> listaApostas = new  ArrayList<InfoApostaDTO>();
    	
    	//Info do utilizador do microservico dos utilizadores
    			List<Utilizador> utilizadorInfo = new ArrayList<Utilizador>();
    			String URLUser = "http://localhost:8082/api/utilizadors";
    			utilizadorInfo =  new RestTemplate().getForObject(URLUser, ArrayList.class);
    			System.out.println(utilizadorInfo);
    			
    			//Info do evento do microservico dos eventos
    			List<Evento> eventoInfo = new ArrayList<Evento>();
    			String URLEvento = "http://localhost:8081/api/eventos";
    			eventoInfo = new RestTemplate().getForObject(URLEvento, ArrayList.class);
    			System.out.println(eventoInfo);
    			
    			//Info dos participantes do microservico dos eventos
    			List<Participante> partipantesInfo = new ArrayList<Participante>();
    			String URLParticipantes = "http://localhost:8081/api/participantes/";
    			partipantesInfo = new RestTemplate().getForObject(URLParticipantes, ArrayList.class);
    			System.out.println(partipantesInfo);
    			
    		
    	 try {
    		listaApostas = apostaService.todasApostas(utilizadorInfo, eventoInfo, partipantesInfo);
    		 
    		 	
     	} catch (Exception e) {
     	  
     	}
         return new ResponseEntity<>(listaApostas, HttpStatus.OK);
     }
    
    
     


}
