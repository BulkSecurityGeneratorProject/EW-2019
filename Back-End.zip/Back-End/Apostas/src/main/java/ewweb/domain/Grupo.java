package ewweb.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Grupo.
 */
@Entity
@Table(name = "grupo")
public class Grupo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "groupname", nullable = false)
    private String groupname;

    @ManyToMany(mappedBy = "grupos")
    @JsonIgnore
    private Set<Utilizador> utilizadors = new HashSet<>();

    @ManyToMany
    @JoinTable(name = "grupo_modulo",
               joinColumns = @JoinColumn(name="grupos_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="modulos_id", referencedColumnName="ID"))
    private Set<Modulo> modulos = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGroupname() {
        return groupname;
    }

    public Grupo groupname(String groupname) {
        this.groupname = groupname;
        return this;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public Set<Utilizador> getUtilizadors() {
        return utilizadors;
    }

    public Grupo utilizadors(Set<Utilizador> utilizadors) {
        this.utilizadors = utilizadors;
        return this;
    }

    public Grupo addUtilizador(Utilizador utilizador) {
        utilizadors.add(utilizador);
        utilizador.getGrupos().add(this);
        return this;
    }

    public Grupo removeUtilizador(Utilizador utilizador) {
        utilizadors.remove(utilizador);
        utilizador.getGrupos().remove(this);
        return this;
    }

    public void setUtilizadors(Set<Utilizador> utilizadors) {
        this.utilizadors = utilizadors;
    }

    public Set<Modulo> getModulos() {
        return modulos;
    }

    public Grupo modulos(Set<Modulo> modulos) {
        this.modulos = modulos;
        return this;
    }

    public Grupo addModulo(Modulo modulo) {
        modulos.add(modulo);
        modulo.getGrupos().add(this);
        return this;
    }

    public Grupo removeModulo(Modulo modulo) {
        modulos.remove(modulo);
        modulo.getGrupos().remove(this);
        return this;
    }

    public void setModulos(Set<Modulo> modulos) {
        this.modulos = modulos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Grupo grupo = (Grupo) o;
        if (grupo.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, grupo.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Grupo{" +
            "id=" + id +
            ", groupname='" + groupname + "'" +
            '}';
    }
}
