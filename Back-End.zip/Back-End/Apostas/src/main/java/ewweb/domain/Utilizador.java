package ewweb.domain;


import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Utilizador.
 */
@Entity
@Table(name = "utilizador")
public class Utilizador implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "username", nullable = false)
    private String username;

    @NotNull
    @Column(name = "password", nullable = false)
    private String password;

    @NotNull
    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "plafond")
    private Float plafond;

    @ManyToMany
    @JoinTable(name = "utilizador_grupo",
               joinColumns = @JoinColumn(name="utilizadors_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="grupos_id", referencedColumnName="ID"))
    private Set<Grupo> grupos = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public Utilizador username(String username) {
        this.username = username;
        return this;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public Utilizador password(String password) {
        this.password = password;
        return this;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public Utilizador email(String email) {
        this.email = email;
        return this;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Float getPlafond() {
        return plafond;
    }

    public Utilizador plafond(Float plafond) {
        this.plafond = plafond;
        return this;
    }

    public void setPlafond(Float plafond) {
        this.plafond = plafond;
    }

    public Set<Grupo> getGrupos() {
        return grupos;
    }

    public Utilizador grupos(Set<Grupo> grupos) {
        this.grupos = grupos;
        return this;
    }

    public Utilizador addGrupo(Grupo grupo) {
        grupos.add(grupo);
        grupo.getUtilizadors().add(this);
        return this;
    }

    public Utilizador removeGrupo(Grupo grupo) {
        grupos.remove(grupo);
        grupo.getUtilizadors().remove(this);
        return this;
    }

    public void setGrupos(Set<Grupo> grupos) {
        this.grupos = grupos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Utilizador utilizador = (Utilizador) o;
        if (utilizador.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, utilizador.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Utilizador{" +
            "id=" + id +
            ", username='" + username + "'" +
            ", password='" + password + "'" +
            ", email='" + email + "'" +
            ", plafond='" + plafond + "'" +
            '}';
    }
}
