/**
 * JPA domain objects.
 */
package ewweb.domain;
