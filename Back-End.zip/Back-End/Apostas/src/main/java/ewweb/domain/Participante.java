package ewweb.domain;


import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Participante.
 */
@Entity
@Table(name = "participante")
public class Participante implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "nome", nullable = false)
    private String nome;

    @NotNull
    @Column(name = "odd_vencer", nullable = false)
    private Double odd_vencer;

    @Column(name = "equipa")
    private String equipa;

    @Column(name = "pais")
    private String pais;

    @Column(name = "eventoId")
    private Long eventoId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public Participante nome(String nome) {
        this.nome = nome;
        return this;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getOdd_vencer() {
        return odd_vencer;
    }

    public Participante odd_vencer(Double odd_vencer) {
        this.odd_vencer = odd_vencer;
        return this;
    }

    public void setOdd_vencer(Double odd_vencer) {
        this.odd_vencer = odd_vencer;
    }

    public String getEquipa() {
        return equipa;
    }

    public Participante equipa(String equipa) {
        this.equipa = equipa;
        return this;
    }

    public void setEquipa(String equipa) {
        this.equipa = equipa;
    }

    public String getPais() {
        return pais;
    }

    public Participante pais(String pais) {
        this.pais = pais;
        return this;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public Long getEvento() {
        return eventoId;
    }

    public Participante evento(long evento) {
        this.eventoId = evento;
        return this;
    }

    public void setEventoId(Long evento) {
        this.eventoId = evento;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Participante participante = (Participante) o;
        if (participante.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, participante.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Participante{" +
            "id=" + id +
            ", nome='" + nome + "'" +
            ", odd_vencer='" + odd_vencer + "'" +
            ", equipa='" + equipa + "'" +
            ", pais='" + pais + "'" +
            '}';
    }
}
