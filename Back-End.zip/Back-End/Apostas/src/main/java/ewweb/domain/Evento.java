package ewweb.domain;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A Evento.
 */
@Entity
@Table(name = "evento")
public class Evento implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "n_participante")
    private Integer n_participante;

    @NotNull
    @Column(name = "estado", nullable = false)
    private String estado;

    @Column(name = "vencedor")
    private String vencedor;

    @Column(name = "evento_equipa")
    private Boolean evento_equipa;

    @NotNull
    @Column(name = "odd_empate", nullable = false)
    private Double odd_empate;

    @Column(name = "desporto")
    private String desporto;

    @NotNull
    @Column(name = "publico", nullable = false)
    private Boolean publico;

    @NotNull
    @Column(name = "hora_inicio", nullable = false)
    private String horaInicio;

    @NotNull
    @Column(name = "hora_fim", nullable = false)
    private String horaFim;

    /*@OneToMany(mappedBy = "evento")
    @JsonIgnore
    private Set<Participante> participantes = new HashSet<>();*/

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getn_participante() {
        return n_participante;
    }

    public Evento n_participante(Integer n_participante) {
        this.n_participante = n_participante;
        return this;
    }

    public void setn_participante(Integer n_participante) {
        this.n_participante = n_participante;
    }

    public String getEstado() {
        return estado;
    }

    public Evento estado(String estado) {
        this.estado = estado;
        return this;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getVencedor() {
        return vencedor;
    }

    public Evento vencedor(String vencedor) {
        this.vencedor = vencedor;
        return this;
    }

    public void setVencedor(String vencedor) {
        this.vencedor = vencedor;
    }

    public Boolean isEvento_equipa() {
        return evento_equipa;
    }

    public Evento evento_equipa(Boolean evento_equipa) {
        this.evento_equipa = evento_equipa;
        return this;
    }

    public void setEvento_equipa(Boolean evento_equipa) {
        this.evento_equipa = evento_equipa;
    }

    public Double getOdd_empate() {
        return odd_empate;
    }

    public Evento odd_empate(Double odd_empate) {
        this.odd_empate = odd_empate;
        return this;
    }

    public void setOdd_empate(Double odd_empate) {
        this.odd_empate = odd_empate;
    }

    public String getDesporto() {
        return desporto;
    }

    public Evento desporto(String desporto) {
        this.desporto = desporto;
        return this;
    }

    public void setDesporto(String desporto) {
        this.desporto = desporto;
    }

    public Boolean isPublico() {
        return publico;
    }

    public Evento publico(Boolean publico) {
        this.publico = publico;
        return this;
    }

    public void setPublico(Boolean publico) {
        this.publico = publico;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public Evento horaInicio(String horaInicio) {
        this.horaInicio = horaInicio;
        return this;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFim() {
        return horaFim;
    }

    public Evento horaFim(String horaFim) {
        this.horaFim = horaFim;
        return this;
    }

    public void setHoraFim(String horaFim) {
        this.horaFim = horaFim;
    }

  /*  public Set<Participante> getParticipantes() {
        return participantes;
    }

    public Evento participantes(Set<Participante> participantes) {
        this.participantes = participantes;
        return this;
    }*/

   /* public Evento addParticipante(Participante participante) {
        participantes.add(participante);
        participante.setEvento(this);
        return this;
    }

    public Evento removeParticipante(Participante participante) {
        participantes.remove(participante);
        participante.setEvento(null);
        return this;
    }

    public void setParticipantes(Set<Participante> participantes) {
        this.participantes = participantes;
    }*/

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Evento evento = (Evento) o;
        if (evento.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, evento.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Evento{" +
            "id=" + id +
            ", n_participante='" + n_participante + "'" +
            ", estado='" + estado + "'" +
            ", vencedor='" + vencedor + "'" +
            ", evento_equipa='" + evento_equipa + "'" +
            ", odd_empate='" + odd_empate + "'" +
            ", desporto='" + desporto + "'" +
            ", publico='" + publico + "'" +
            ", horaInicio='" + horaInicio + "'" +
            ", horaFim='" + horaFim + "'" +
            '}';
    }
}
