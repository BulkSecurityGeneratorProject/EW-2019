package ewweb.domain;

import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Aposta.
 */
@Entity
@Table(name = "aposta")
@Document(indexName = "aposta")
public class Aposta implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "estado", nullable = false)
    private String estado;

    @NotNull
    @Column(name = "montante", nullable = false)
    private Float montante;

    @Column(name = "resultado")
    private Float resultado;

    @NotNull
    @Column(name = "utilizador", nullable = false)
    private Integer utilizador;

    @NotNull
    @Column(name = "evento", nullable = false)
    private Integer evento;

    @NotNull
    @Column(name = "participante", nullable = false)
    private Integer participante;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEstado() {
        return estado;
    }

    public Aposta estado(String estado) {
        this.estado = estado;
        return this;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Float getMontante() {
        return montante;
    }

    public Aposta montante(Float montante) {
        this.montante = montante;
        return this;
    }

    public void setMontante(Float montante) {
        this.montante = montante;
    }

    public Float getResultado() {
        return resultado;
    }

    public Aposta resultado(Float resultado) {
        this.resultado = resultado;
        return this;
    }

    public void setResultado(Float resultado) {
        this.resultado = resultado;
    }

    public Integer getUtilizador() {
        return utilizador;
    }

    public Aposta utilizador(Integer utilizador) {
        this.utilizador = utilizador;
        return this;
    }

    public void setUtilizador(Integer utilizador) {
        this.utilizador = utilizador;
    }

    public Integer getEvento() {
        return evento;
    }

    public Aposta evento(Integer evento) {
        this.evento = evento;
        return this;
    }

    public void setEvento(Integer evento) {
        this.evento = evento;
    }

    public Integer getParticipante() {
        return participante;
    }

    public Aposta participante(Integer participante) {
        this.participante = participante;
        return this;
    }

    public void setParticipante(Integer participante) {
        this.participante = participante;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Aposta aposta = (Aposta) o;
        if (aposta.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, aposta.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Aposta{" +
            "id=" + id +
            ", estado='" + estado + "'" +
            ", montante='" + montante + "'" +
            ", resultado='" + resultado + "'" +
            ", utilizador='" + utilizador + "'" +
            ", evento='" + evento + "'" +
            ", participante='" + participante + "'" +
            '}';
    }
}
