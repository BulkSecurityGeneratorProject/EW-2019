package ewweb.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Modulo.
 */
@Entity
@Table(name = "modulo")
public class Modulo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "moduleid", nullable = false)
    private String moduleid;

    @NotNull
    @Column(name = "modulename", nullable = false)
    private String modulename;

    @ManyToMany(mappedBy = "modulos")
    @JsonIgnore
    private Set<Grupo> grupos = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModuleid() {
        return moduleid;
    }

    public Modulo moduleid(String moduleid) {
        this.moduleid = moduleid;
        return this;
    }

    public void setModuleid(String moduleid) {
        this.moduleid = moduleid;
    }

    public String getModulename() {
        return modulename;
    }

    public Modulo modulename(String modulename) {
        this.modulename = modulename;
        return this;
    }

    public void setModulename(String modulename) {
        this.modulename = modulename;
    }

    public Set<Grupo> getGrupos() {
        return grupos;
    }

    public Modulo grupos(Set<Grupo> grupos) {
        this.grupos = grupos;
        return this;
    }

    public Modulo addGrupo(Grupo grupo) {
        grupos.add(grupo);
        grupo.getModulos().add(this);
        return this;
    }

    public Modulo removeGrupo(Grupo grupo) {
        grupos.remove(grupo);
        grupo.getModulos().remove(this);
        return this;
    }

    public void setGrupos(Set<Grupo> grupos) {
        this.grupos = grupos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Modulo modulo = (Modulo) o;
        if (modulo.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, modulo.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Modulo{" +
            "id=" + id +
            ", moduleid='" + moduleid + "'" +
            ", modulename='" + modulename + "'" +
            '}';
    }
}
