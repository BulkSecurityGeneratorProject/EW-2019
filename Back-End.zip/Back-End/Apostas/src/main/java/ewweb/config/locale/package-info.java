/**
 * Locale specific code.
 */
package ewweb.config.locale;
