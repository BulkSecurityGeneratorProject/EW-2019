package ewweb.config;

import java.text.SimpleDateFormat;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import ewweb.web.rest.ApostaResource;

	@Component
	public class UpdateEventsAndBetsTask {
		
		 private static final Logger log = LoggerFactory.getLogger(UpdateEventsAndBetsTask.class);
	
		 @Inject
		 private ApostaResource ev;

		    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

		  @Scheduled(fixedRate = 3600000)
		    public void reportCurrentTime(){
			  
		        log.info("Time to update events and bets", ev.atualizaTudo().toString());
		    	log.info("This update occures hour to hour.");
		        
		    }
		    
		    
	}

