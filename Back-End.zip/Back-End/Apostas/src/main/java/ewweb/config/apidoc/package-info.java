/**
 * Swagger api specific code.
 */
package ewweb.config.apidoc;