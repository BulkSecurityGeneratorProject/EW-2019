/**
 * Async helpers.
 */
package ewweb.async;
