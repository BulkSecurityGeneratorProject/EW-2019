package ewweb.service.mapper;

import ewweb.domain.*;
import ewweb.service.dto.ApostaDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Aposta and its DTO ApostaDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ApostaMapper {

    ApostaDTO apostaToApostaDTO(Aposta aposta);

    List<ApostaDTO> apostasToApostaDTOs(List<Aposta> apostas);

    Aposta apostaDTOToAposta(ApostaDTO apostaDTO);

    List<Aposta> apostaDTOsToApostas(List<ApostaDTO> apostaDTOs);
}
