package ewweb.service;

import ewweb.service.dto.ApostaDTO;
import java.util.List;

/**
 * Service Interface for managing Aposta.
 */
public interface ApostaService {

    /**
     * Save a aposta.
     *
     * @param apostaDTO the entity to save
     * @return the persisted entity
     */
    ApostaDTO save(ApostaDTO apostaDTO);

    /**
     *  Get all the apostas.
     *  
     *  @return the list of entities
     */
    List<ApostaDTO> findAll();

    /**
     *  Get the "id" aposta.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    ApostaDTO findOne(Long id);

    /**
     *  Delete the "id" aposta.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the aposta corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<ApostaDTO> search(String query);
}
