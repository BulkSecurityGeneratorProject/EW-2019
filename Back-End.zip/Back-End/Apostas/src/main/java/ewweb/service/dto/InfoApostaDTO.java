package ewweb.service.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;

import ewweb.domain.Participante;

public class InfoApostaDTO implements Serializable {
	
	   private Long id;

	    @NotNull
	    private String estado;

	    @NotNull
	    private Float montante;

	    private Float resultado;

	    @NotNull
	    private Long utilizador_id;
	    
	    @NotNull
	    private String utilizador_nome;
	    
	    @NotNull
	    private String utilizador_email;
	   
	    @NotNull
	    private Long evento_id;
	    
	    @NotNull
	    private String evento_estado;
	    
	    
	    private String evento_vencedor;
	    
	    @NotNull
	    private Double evento_oddEmpate;
	    
	    @NotNull
	    private String evento_desporto;
	    
	    @NotNull
	    private String evento_Inicio;
	    
	    @NotNull
	    private String evento_Fim;
	    
	    @NotNull
	    private boolean evento_publico;


	    @NotNull
	    private Long participante_id;
	    
	    @NotNull
	    private String participante_nome;
	    
	    @NotNull
	    private Double participante_odd;
	    
	    private String participante_equipa;
	    
	    @NotNull
	    private String participante_pais;
	    
	    @NotNull
	    private Long participante_evento;
	    
	    @NotNull
	    private List<Participante> outrosParticipante;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getEstado() {
			return estado;
		}

		public void setEstado(String estado) {
			this.estado = estado;
		}

		public Float getMontante() {
			return montante;
		}

		public void setMontante(Float montante) {
			this.montante = montante;
		}

		public Float getResultado() {
			return resultado;
		}

		public void setResultado(Float resultado) {
			this.resultado = resultado;
		}

		public Long getUtilizador_id() {
			return utilizador_id;
		}

		public void setUtilizador_id(Long utilizador_id) {
			this.utilizador_id = utilizador_id;
		}

		public String getUtilizador_nome() {
			return utilizador_nome;
		}

		public void setUtilizador_nome(String utilizador_nome) {
			this.utilizador_nome = utilizador_nome;
		}

		public String getUtilizador_email() {
			return utilizador_email;
		}

		public void setUtilizador_email(String utilizador_email) {
			this.utilizador_email = utilizador_email;
		}

		public Long getEvento_id() {
			return evento_id;
		}

		public void setEvento_id(Long evento_id) {
			this.evento_id = evento_id;
		}

		public String getEvento_estado() {
			return evento_estado;
		}

		public void setEvento_estado(String evento_estado) {
			this.evento_estado = evento_estado;
		}

		public String getEvento_vencedor() {
			return evento_vencedor;
		}

		public void setEvento_vencedor(String evento_vencedor) {
			this.evento_vencedor = evento_vencedor;
		}

		public Double getEvento_oddEmpate() {
			return evento_oddEmpate;
		}

		public void setEvento_oddEmpate(Double double1) {
			this.evento_oddEmpate = double1;
		}

		public String getEvento_desporto() {
			return evento_desporto;
		}

		public void setEvento_desporto(String evento_desporto) {
			this.evento_desporto = evento_desporto;
		}

		public String getEvento_Inicio() {
			return evento_Inicio;
		}

		public void setEvento_Inicio(String evento_Inicio) {
			this.evento_Inicio = evento_Inicio;
		}

		public String getEvento_Fim() {
			return evento_Fim;
		}

		public void setEvento_Fim(String evento_Fim) {
			this.evento_Fim = evento_Fim;
		}

		public boolean getEvento_publico() {
			return evento_publico;
		}

		public void setEvento_publico(boolean evento_publico) {
			this.evento_publico = evento_publico;
		}

		public Long getParticipante_id() {
			return participante_id;
		}

		public void setParticipante_id(Long participante_id) {
			this.participante_id = participante_id;
		}

		public String getParticipante_nome() {
			return participante_nome;
		}

		public void setParticipante_nome(String participante_nome) {
			this.participante_nome = participante_nome;
		}

		public Double getParticipante_odd() {
			return participante_odd;
		}

		public void setParticipante_odd(Double participante_odd) {
			this.participante_odd = participante_odd;
		}

		public String getParticipante_equipa() {
			return participante_equipa;
		}

		public void setParticipante_equipa(String participante_equipa) {
			this.participante_equipa = participante_equipa;
		}

		public String getParticipante_pais() {
			return participante_pais;
		}

		public void setParticipante_pais(String participante_pais) {
			this.participante_pais = participante_pais;
		}

		public Long getParticipante_evento() {
			return participante_evento;
		}

		public void setParticipante_evento(Long participante_evento) {
			this.participante_evento = participante_evento;
		}

		public List<Participante> getOutrosParticipante() {
			return outrosParticipante;
		}

		public void setOutrosParticipante(List<Participante> outrosParticipante) {
			this.outrosParticipante = outrosParticipante;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((estado == null) ? 0 : estado.hashCode());
			result = prime * result + ((evento_Fim == null) ? 0 : evento_Fim.hashCode());
			result = prime * result + ((evento_Inicio == null) ? 0 : evento_Inicio.hashCode());
			result = prime * result + ((evento_desporto == null) ? 0 : evento_desporto.hashCode());
			result = prime * result + ((evento_estado == null) ? 0 : evento_estado.hashCode());
			result = prime * result + ((evento_id == null) ? 0 : evento_id.hashCode());
			result = prime * result + ((evento_oddEmpate == null) ? 0 : evento_oddEmpate.hashCode());
			result = prime * result + (evento_publico ? 1231 : 1237);
			result = prime * result + ((evento_vencedor == null) ? 0 : evento_vencedor.hashCode());
			result = prime * result + ((id == null) ? 0 : id.hashCode());
			result = prime * result + ((montante == null) ? 0 : montante.hashCode());
			result = prime * result + ((outrosParticipante == null) ? 0 : outrosParticipante.hashCode());
			result = prime * result + ((participante_equipa == null) ? 0 : participante_equipa.hashCode());
			result = prime * result + ((participante_evento == null) ? 0 : participante_evento.hashCode());
			result = prime * result + ((participante_id == null) ? 0 : participante_id.hashCode());
			result = prime * result + ((participante_nome == null) ? 0 : participante_nome.hashCode());
			result = prime * result + ((participante_odd == null) ? 0 : participante_odd.hashCode());
			result = prime * result + ((participante_pais == null) ? 0 : participante_pais.hashCode());
			result = prime * result + ((resultado == null) ? 0 : resultado.hashCode());
			result = prime * result + ((utilizador_email == null) ? 0 : utilizador_email.hashCode());
			result = prime * result + ((utilizador_id == null) ? 0 : utilizador_id.hashCode());
			result = prime * result + ((utilizador_nome == null) ? 0 : utilizador_nome.hashCode());
			return result;
		}

		

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			InfoApostaDTO other = (InfoApostaDTO) obj;
			if (estado == null) {
				if (other.estado != null)
					return false;
			} else if (!estado.equals(other.estado))
				return false;
			if (evento_Fim == null) {
				if (other.evento_Fim != null)
					return false;
			} else if (!evento_Fim.equals(other.evento_Fim))
				return false;
			if (evento_Inicio == null) {
				if (other.evento_Inicio != null)
					return false;
			} else if (!evento_Inicio.equals(other.evento_Inicio))
				return false;
			if (evento_desporto == null) {
				if (other.evento_desporto != null)
					return false;
			} else if (!evento_desporto.equals(other.evento_desporto))
				return false;
			if (evento_estado == null) {
				if (other.evento_estado != null)
					return false;
			} else if (!evento_estado.equals(other.evento_estado))
				return false;
			if (evento_id == null) {
				if (other.evento_id != null)
					return false;
			} else if (!evento_id.equals(other.evento_id))
				return false;
			if (evento_oddEmpate == null) {
				if (other.evento_oddEmpate != null)
					return false;
			} else if (!evento_oddEmpate.equals(other.evento_oddEmpate))
				return false;
			if (evento_publico != other.evento_publico)
				return false;
			if (evento_vencedor == null) {
				if (other.evento_vencedor != null)
					return false;
			} else if (!evento_vencedor.equals(other.evento_vencedor))
				return false;
			if (id == null) {
				if (other.id != null)
					return false;
			} else if (!id.equals(other.id))
				return false;
			if (montante == null) {
				if (other.montante != null)
					return false;
			} else if (!montante.equals(other.montante))
				return false;
			if (outrosParticipante == null) {
				if (other.outrosParticipante != null)
					return false;
			} else if (!outrosParticipante.equals(other.outrosParticipante))
				return false;
			if (participante_equipa == null) {
				if (other.participante_equipa != null)
					return false;
			} else if (!participante_equipa.equals(other.participante_equipa))
				return false;
			if (participante_evento == null) {
				if (other.participante_evento != null)
					return false;
			} else if (!participante_evento.equals(other.participante_evento))
				return false;
			if (participante_id == null) {
				if (other.participante_id != null)
					return false;
			} else if (!participante_id.equals(other.participante_id))
				return false;
			if (participante_nome == null) {
				if (other.participante_nome != null)
					return false;
			} else if (!participante_nome.equals(other.participante_nome))
				return false;
			if (participante_odd == null) {
				if (other.participante_odd != null)
					return false;
			} else if (!participante_odd.equals(other.participante_odd))
				return false;
			if (participante_pais == null) {
				if (other.participante_pais != null)
					return false;
			} else if (!participante_pais.equals(other.participante_pais))
				return false;
			if (resultado == null) {
				if (other.resultado != null)
					return false;
			} else if (!resultado.equals(other.resultado))
				return false;
			if (utilizador_email == null) {
				if (other.utilizador_email != null)
					return false;
			} else if (!utilizador_email.equals(other.utilizador_email))
				return false;
			if (utilizador_id == null) {
				if (other.utilizador_id != null)
					return false;
			} else if (!utilizador_id.equals(other.utilizador_id))
				return false;
			if (utilizador_nome == null) {
				if (other.utilizador_nome != null)
					return false;
			} else if (!utilizador_nome.equals(other.utilizador_nome))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "InfoApostaDTO [id=" + id + ", estado=" + estado + ", montante=" + montante + ", resultado="
					+ resultado + ", utilizador_id=" + utilizador_id + ", utilizador_nome=" + utilizador_nome
					+ ", utilizador_email=" + utilizador_email + ", evento_id=" + evento_id + ", evento_estado="
					+ evento_estado + ", evento_vencedor=" + evento_vencedor + ", evento_oddEmpate=" + evento_oddEmpate
					+ ", evento_desporto=" + evento_desporto + ", evento_Inicio=" + evento_Inicio + ", evento_Fim="
					+ evento_Fim + ", evento_publico=" + evento_publico + ", participante_id=" + participante_id
					+ ", participante_nome=" + participante_nome + ", participante_odd=" + participante_odd
					+ ", participante_equipa=" + participante_equipa + ", participante_pais=" + participante_pais
					+ ", participante_evento=" + participante_evento + ", outrosParticipante=" + outrosParticipante
					+ "]";
		}

	    
	    
}
