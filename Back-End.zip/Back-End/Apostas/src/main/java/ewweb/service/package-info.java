/**
 * Service layer beans.
 */
package ewweb.service;
