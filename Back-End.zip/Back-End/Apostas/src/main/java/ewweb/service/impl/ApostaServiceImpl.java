package ewweb.service.impl;

import ewweb.service.ApostaService;
import ewweb.domain.Aposta;
import ewweb.repository.ApostaRepository;
import ewweb.repository.search.ApostaSearchRepository;
import ewweb.service.dto.ApostaDTO;
import ewweb.service.mapper.ApostaMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Aposta.
 */
@Service
@Transactional
public class ApostaServiceImpl implements ApostaService{

    private final Logger log = LoggerFactory.getLogger(ApostaServiceImpl.class);
    
    @Inject
    private ApostaRepository apostaRepository;

    @Inject
    private ApostaMapper apostaMapper;

    @Inject
    private ApostaSearchRepository apostaSearchRepository;

    /**
     * Save a aposta.
     *
     * @param apostaDTO the entity to save
     * @return the persisted entity
     */
    public ApostaDTO save(ApostaDTO apostaDTO) {
        log.debug("Request to save Aposta : {}", apostaDTO);
        Aposta aposta = apostaMapper.apostaDTOToAposta(apostaDTO);
        aposta = apostaRepository.save(aposta);
        ApostaDTO result = apostaMapper.apostaToApostaDTO(aposta);
        apostaSearchRepository.save(aposta);
        return result;
    }

    /**
     *  Get all the apostas.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<ApostaDTO> findAll() {
        log.debug("Request to get all Apostas");
        List<ApostaDTO> result = apostaRepository.findAll().stream()
            .map(apostaMapper::apostaToApostaDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one aposta by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ApostaDTO findOne(Long id) {
        log.debug("Request to get Aposta : {}", id);
        Aposta aposta = apostaRepository.findOne(id);
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);
        return apostaDTO;
    }

    /**
     *  Delete the  aposta by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Aposta : {}", id);
        apostaRepository.delete(id);
        apostaSearchRepository.delete(id);
    }

    /**
     * Search for the aposta corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<ApostaDTO> search(String query) {
        log.debug("Request to search Apostas for query {}", query);
        return StreamSupport
            .stream(apostaSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(apostaMapper::apostaToApostaDTO)
            .collect(Collectors.toList());
    }
}
