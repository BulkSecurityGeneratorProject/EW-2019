package ewweb.service.impl;

import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import ewweb.domain.Aposta;
import ewweb.domain.Evento;
import ewweb.domain.Participante;
import ewweb.domain.Utilizador;
import ewweb.repository.ApostaRepository;
import ewweb.repository.search.ApostaSearchRepository;
import ewweb.service.ApostaService;
import ewweb.service.dto.ApostaDTO;
import ewweb.service.dto.InfoApostaDTO;
import ewweb.service.mapper.ApostaMapper;

/**
 * Service Implementation for managing Aposta.
 */
@Service
@Transactional
public class ApostaServiceImpl implements ApostaService{

    private final Logger log = LoggerFactory.getLogger(ApostaServiceImpl.class);
    
    @Inject
    private ApostaRepository apostaRepository;

    @Inject
    private ApostaMapper apostaMapper;

    @Inject
    private ApostaSearchRepository apostaSearchRepository;

    /**
     * Save a aposta.
     *
     * @param apostaDTO the entity to save
     * @return the persisted entity
     */
    public ApostaDTO save(ApostaDTO apostaDTO) {
        log.debug("Request to save Aposta : {}", apostaDTO);
        Aposta aposta = apostaMapper.apostaDTOToAposta(apostaDTO);
        aposta = apostaRepository.save(aposta);
        ApostaDTO result = apostaMapper.apostaToApostaDTO(aposta);
        apostaSearchRepository.save(aposta);
        return result;
    }

    /**
     *  Get all the apostas.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<ApostaDTO> findAll() {
        log.debug("Request to get all Apostas");
        List<ApostaDTO> result = apostaRepository.findAll().stream()
            .map(apostaMapper::apostaToApostaDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one aposta by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ApostaDTO findOne(Long id) {
        log.debug("Request to get Aposta : {}", id);
        Aposta aposta = apostaRepository.findOne(id);
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);
        return apostaDTO;
    }

    /**
     *  Delete the  aposta by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Aposta : {}", id);
        apostaRepository.delete(id);
        apostaSearchRepository.delete(id);
    }

    /**
     * Search for the aposta corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<ApostaDTO> search(String query) {
        log.debug("Request to search Apostas for query {}", query);
        return StreamSupport
            .stream(apostaSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(apostaMapper::apostaToApostaDTO)
            .collect(Collectors.toList());
    }

	@Override
	public List<InfoApostaDTO> utilizadorApostas(Utilizador utilizadorInfo, Evento eventoInfo, Participante partipantesInfo, List<Participante> partipantesTodosInfo) {
		List<InfoApostaDTO> listaApostas = new ArrayList<InfoApostaDTO>();
	
		
		
		//Info das apostas
		List <Aposta> todasApostas = apostaRepository.findAll();
		
		//Preenche o DTO
		for(Aposta ap: todasApostas){
			InfoApostaDTO infoAp = new InfoApostaDTO();
			infoAp.setId(ap.getId());
			infoAp.setEstado(ap.getEstado());
			infoAp.setMontante(ap.getMontante());
			infoAp.setResultado(ap.getResultado());
			infoAp.setUtilizador_id(utilizadorInfo.getId());
			infoAp.setUtilizador_nome(utilizadorInfo.getUsername());
			infoAp.setUtilizador_email(utilizadorInfo.getEmail());
			infoAp.setEvento_id(eventoInfo.getId());
			infoAp.setEvento_estado(eventoInfo.getEstado());
			infoAp.setEvento_vencedor(eventoInfo.getVencedor());
			infoAp.setEvento_oddEmpate(eventoInfo.getOdd_empate());
			infoAp.setEvento_desporto(eventoInfo.getDesporto());
			infoAp.setEvento_Inicio(eventoInfo.getHoraInicio());
			infoAp.setEvento_Fim(eventoInfo.getHoraFim());
			infoAp.setEvento_publico(eventoInfo.isPublico());
			//boolean encontrou = false;
			//int i = 0;
			
			/*while(encontrou == false && i < auxLista.size()) {
				Long idAux = new Long(partipantesInfo.get(i).getId());
				Integer intAux = idAux.intValue();
				if (intAux == ap.getParticipante()) {*/
					infoAp.setParticipante_id(partipantesInfo.getId());
					infoAp.setParticipante_nome(partipantesInfo.getNome());
					infoAp.setParticipante_equipa(partipantesInfo.getEquipa());
					infoAp.setParticipante_odd(partipantesInfo.getOdd_vencer());
					infoAp.setParticipante_pais(partipantesInfo.getPais());
					infoAp.setParticipante_evento(eventoInfo.getId());
					//infoAp.setOutrosParticipante(auxLista);
				/*}
				i++;
			}*/
					infoAp.setOutrosParticipante(partipantesTodosInfo);
			
			listaApostas.add(infoAp);
			
		}
	
		
		
		return listaApostas;
	}

	@Override
	public List<ApostaDTO> novaAposta(Long utilizador, Long evento, Long participante, Float montante) {
		List<Aposta> listaApostas = new ArrayList<Aposta>();
		List<ApostaDTO> listaApostasDTO = new ArrayList<ApostaDTO>();
		Aposta aposta = new Aposta();
		aposta.setEstado("aberto");
		aposta.setMontante(montante);
		aposta.setEvento(evento.intValue());
		aposta.setParticipante(participante.intValue());
		aposta.setUtilizador(utilizador.intValue());
		
		apostaRepository.saveAndFlush(aposta);
		
		listaApostas = apostaRepository.findByUtilizadorAndEstado(utilizador.intValue(),"aberto");
		listaApostasDTO = apostaMapper.apostasToApostaDTOs(listaApostas);
		
		return listaApostasDTO;
	}
	
	@Override
	public List<ApostaDTO> novaApostaEmpate(Long utilizador, Long evento, Float montante) {
		List<Aposta> listaApostas = new ArrayList<Aposta>();
		List<ApostaDTO> listaApostasDTO = new ArrayList<ApostaDTO>();
		Aposta aposta = new Aposta();
		aposta.setEstado("aberto");
		aposta.setMontante(montante);
		aposta.setEvento(evento.intValue());
		
		aposta.setUtilizador(utilizador.intValue());
		
		apostaRepository.saveAndFlush(aposta);
		
		listaApostas = apostaRepository.findByUtilizadorAndEstado(utilizador.intValue(),"aberto");
		listaApostasDTO = apostaMapper.apostasToApostaDTOs(listaApostas);
		
		return listaApostasDTO;
	}
	
	@Override
	public List<ApostaDTO> eliminaAposta(Long utilizador, Long aposta) {
		List<Aposta> listaApostas = new ArrayList<Aposta>();
		List<ApostaDTO> listaApostasDTO = new ArrayList<ApostaDTO>();
		Aposta apostaInfo = new Aposta();
		apostaInfo = apostaRepository.findByid(aposta);
		
		apostaRepository.delete(apostaInfo);
		
		listaApostas = apostaRepository.findByUtilizadorAndEstado(utilizador.intValue(),"aberto");
		listaApostasDTO = apostaMapper.apostasToApostaDTOs(listaApostas);
		
		return listaApostasDTO;
	}

	@Override
	public List<ApostaDTO> fechaAposta(Long utilizador, Long aposta) {
		List<Aposta> listaApostas = new ArrayList<Aposta>();
		List<ApostaDTO> listaApostasDTO = new ArrayList<ApostaDTO>();
		Aposta apostaInfo = new Aposta();
		apostaInfo = apostaRepository.findByid(aposta);
		apostaInfo.setEstado("fechado");
		
		apostaRepository.saveAndFlush(apostaInfo);
		
		listaApostas = apostaRepository.findAllByUtilizador(utilizador.intValue());
		listaApostasDTO = apostaMapper.apostasToApostaDTOs(listaApostas);
		
		return listaApostasDTO;
	}

	@Override
	public List<InfoApostaDTO> utilizadorApostasAbertas(Utilizador utilizadorInfo, List<Evento> eventoInfo, List<Participante> partipantesInfo) {
		List<InfoApostaDTO> listaApostas = new ArrayList<InfoApostaDTO>();
		
		ObjectMapper mapper = new ObjectMapper();
		List<Evento> eventoCon = mapper.convertValue(eventoInfo, new TypeReference<List<Evento>>(){}
				);
		
		System.out.println(eventoCon.toString());
		
		List<Participante> participanteCon = mapper.convertValue(
				partipantesInfo, 
			    new TypeReference<List<Participante>>(){}
			);
	
		
		System.out.println(participanteCon.toString());
		
		
		List<Aposta> apostas = apostaRepository.findAllByUtilizador(utilizadorInfo.getId().intValue());
		
		System.out.println(apostas.toString());
		for(Evento e: eventoCon) {
			for(Aposta a : apostas) {
				
				System.out.println("Aposta id "+ a.getId() + ": " + a.getEvento() + " " + "Evento: " +e.getId().intValue());
				if(a.getEvento().equals(e.getId().intValue())) {
					System.out.println("ENTROU");
					InfoApostaDTO infoAp = new InfoApostaDTO();
					infoAp.setId(a.getId());
					infoAp.setEstado(a.getEstado());
					infoAp.setMontante(a.getMontante());
					infoAp.setResultado(a.getResultado());
					infoAp.setUtilizador_id(utilizadorInfo.getId());
					infoAp.setUtilizador_nome(utilizadorInfo.getUsername());
					infoAp.setUtilizador_email(utilizadorInfo.getEmail());
					infoAp.setEvento_id(e.getId());
					infoAp.setEvento_estado(e.getEstado());
					infoAp.setEvento_vencedor(e.getVencedor());
					infoAp.setEvento_oddEmpate(e.getOdd_empate());
					infoAp.setEvento_desporto(e.getDesporto());
					infoAp.setEvento_Inicio(e.getHoraInicio());
					infoAp.setEvento_Fim(e.getHoraFim());
					infoAp.setEvento_publico(e.isPublico());
					
					if(a.getParticipante() != null) {
						infoAp.setParticipante_id((long)a.getParticipante());
					}else {
						infoAp.setParticipante_id(null);
						infoAp.setParticipante_nome("TIE");
						infoAp.setParticipante_odd(e.getOdd_empate());
					}
					
					List<Participante> participanteEvento = new ArrayList<Participante>();
					for(Participante p: participanteCon) {
						if (a.getParticipante() != null && a.getParticipante() == p.getId().intValue()) {
							infoAp.setParticipante_id(p.getId());
							infoAp.setParticipante_nome(p.getNome());
							infoAp.setParticipante_equipa(p.getEquipa());
							infoAp.setParticipante_odd(p.getOdd_vencer());
							infoAp.setParticipante_pais(p.getPais());
							infoAp.setParticipante_evento(p.getId());
						}
						else if(p.getEvento().equals(e.getId())) {
							participanteEvento.add(p);
						}
					}
					infoAp.setOutrosParticipante(participanteEvento);
					
					listaApostas.add(infoAp);
					
				}
				
				
			}
		}
		

		return listaApostas;
	}

	@Override
	public List<InfoApostaDTO> historicoApostas(Utilizador utilizadorInfo, List<Evento> eventoInfo,
			List<Participante> partipantesInfo) {
		List<InfoApostaDTO> listaApostas = new ArrayList<InfoApostaDTO>();
		
		ObjectMapper mapper = new ObjectMapper();
		List<Evento> eventoCon = mapper.convertValue(eventoInfo, new TypeReference<List<Evento>>(){}
				);
		
		System.out.println(eventoCon.toString());
		
		List<Participante> participanteCon = mapper.convertValue(
				partipantesInfo, 
			    new TypeReference<List<Participante>>(){}
			);
	
		
		System.out.println(participanteCon.toString());
		
		
		List<Aposta> apostas = apostaRepository.findAllByUtilizador(utilizadorInfo.getId().intValue());
		
		System.out.println(apostas.toString());
		for(Evento e: eventoCon) {
			for(Aposta a : apostas) {
				if(a.getEvento().equals(e.getId().intValue())) {
					System.out.println("ENTROU");
					InfoApostaDTO infoAp = new InfoApostaDTO();
					infoAp.setId(a.getId());
					infoAp.setEstado(a.getEstado());
					infoAp.setMontante(a.getMontante());
					infoAp.setResultado(a.getResultado());
					infoAp.setUtilizador_id(utilizadorInfo.getId());
					infoAp.setUtilizador_nome(utilizadorInfo.getUsername());
					infoAp.setUtilizador_email(utilizadorInfo.getEmail());
					infoAp.setEvento_id(e.getId());
					infoAp.setEvento_estado(e.getEstado());
					infoAp.setEvento_vencedor(e.getVencedor());
					infoAp.setEvento_oddEmpate(e.getOdd_empate());
					infoAp.setEvento_desporto(e.getDesporto());
					infoAp.setEvento_Inicio(e.getHoraInicio());
					infoAp.setEvento_Fim(e.getHoraFim());
					infoAp.setEvento_publico(e.isPublico());
					
					if(a.getParticipante() != null) {
						infoAp.setParticipante_id((long)a.getParticipante());
					}else {
						infoAp.setParticipante_id(null);
						infoAp.setParticipante_nome("TIE");
						infoAp.setParticipante_odd(e.getOdd_empate());
					}
					
					List<Participante> participanteEvento = new ArrayList<Participante>();
					for(Participante p: participanteCon) {
						if (a.getParticipante() != null && a.getParticipante() == p.getId().intValue()) {
							infoAp.setParticipante_id(p.getId());
							infoAp.setParticipante_nome(p.getNome());
							infoAp.setParticipante_equipa(p.getEquipa());
							infoAp.setParticipante_odd(p.getOdd_vencer());
							infoAp.setParticipante_pais(p.getPais());
							infoAp.setParticipante_evento(p.getId());
						}
						else if(p.getEvento().equals(e.getId())) {
							participanteEvento.add(p);
						}
					}
					infoAp.setOutrosParticipante(participanteEvento);
					
					listaApostas.add(infoAp);
					
				}
				
				
			}
		}
		return listaApostas;
	}
	
	public List<InfoApostaDTO> todasAbertasApostas(List<Utilizador> utilizadorInfo, List<Evento> eventoInfo,
			List<Participante> partipantesInfo) {
		List<InfoApostaDTO> listaApostas = new ArrayList<InfoApostaDTO>();
		
		ObjectMapper mapper = new ObjectMapper();
		List<Evento> eventoCon = mapper.convertValue(eventoInfo, new TypeReference<List<Evento>>(){}
				);
		
		System.out.println(eventoCon.toString());
		
		List<Participante> participanteCon = mapper.convertValue(
				partipantesInfo, 
			    new TypeReference<List<Participante>>(){}
			);
		
		List<Utilizador> utilizadorCon = mapper.convertValue(
				utilizadorInfo, 
			    new TypeReference<List<Utilizador>>(){}
			);
	
		
		System.out.println(participanteCon.toString());
		
		
		List<Aposta> apostas = apostaRepository.findByEstado("aberto");
		
		System.out.println(apostas.toString());
		for(Evento e: eventoCon) {
			for(Aposta a : apostas) {
				if(a.getEvento().equals(e.getId().intValue())) {
					System.out.println("ENTROU");
					InfoApostaDTO infoAp = new InfoApostaDTO();
					infoAp.setId(a.getId());
					infoAp.setEstado(a.getEstado());
					infoAp.setMontante(a.getMontante());
					infoAp.setResultado(a.getResultado());
					boolean encontrouUtilizador = false;
					int index = 0;
					while(encontrouUtilizador == false && index < utilizadorCon.size()) {
						if(a.getUtilizador().equals(utilizadorCon.get(index).getId().intValue())) {
							infoAp.setUtilizador_id(utilizadorCon.get(index).getId());
							infoAp.setUtilizador_nome(utilizadorCon.get(index).getUsername());
							infoAp.setUtilizador_email(utilizadorCon.get(index).getEmail());
						}
						index ++;
					}
					infoAp.setEvento_id(e.getId());
					infoAp.setEvento_estado(e.getEstado());
					infoAp.setEvento_vencedor(e.getVencedor());
					infoAp.setEvento_oddEmpate(e.getOdd_empate());
					infoAp.setEvento_desporto(e.getDesporto());
					infoAp.setEvento_Inicio(e.getHoraInicio());
					infoAp.setEvento_Fim(e.getHoraFim());
					infoAp.setEvento_publico(e.isPublico());
					
					
					if(a.getParticipante() != null) {
						infoAp.setParticipante_id((long)a.getParticipante());
					}else {
						infoAp.setParticipante_id(null);
						infoAp.setParticipante_nome("TIE");
						infoAp.setParticipante_odd(e.getOdd_empate());
					}
						List<Participante> participanteEvento = new ArrayList<Participante>();
						for(Participante p: participanteCon) {
							if (a.getParticipante() != null && a.getParticipante() == p.getId().intValue()) {
								infoAp.setParticipante_id(p.getId());
								infoAp.setParticipante_nome(p.getNome());
								infoAp.setParticipante_equipa(p.getEquipa());
								infoAp.setParticipante_odd(p.getOdd_vencer());
								infoAp.setParticipante_pais(p.getPais());
								infoAp.setParticipante_evento(p.getId());
							}
							else if(p.getEvento().equals(e.getId())) {
								participanteEvento.add(p);
							}
						}
						
						infoAp.setOutrosParticipante(participanteEvento);
					
					
					listaApostas.add(infoAp);
					
				}
				
				
			}
		}
		return listaApostas;
	}
	
	public List<InfoApostaDTO> todasFechadasApostas(List<Utilizador> utilizadorInfo, List<Evento> eventoInfo,
			List<Participante> partipantesInfo) {
		List<InfoApostaDTO> listaApostas = new ArrayList<InfoApostaDTO>();
		
		ObjectMapper mapper = new ObjectMapper();
		List<Evento> eventoCon = mapper.convertValue(eventoInfo, new TypeReference<List<Evento>>(){}
				);
		
		System.out.println(eventoCon.toString());
		
		List<Participante> participanteCon = mapper.convertValue(
				partipantesInfo, 
			    new TypeReference<List<Participante>>(){}
			);
		
		List<Utilizador> utilizadorCon = mapper.convertValue(
				utilizadorInfo, 
			    new TypeReference<List<Utilizador>>(){}
			);
	
		
		System.out.println(participanteCon.toString());
		
		
		List<Aposta> apostas = apostaRepository.findByEstado("fechado");
		
		System.out.println(apostas.toString());
		for(Evento e: eventoCon) {
			for(Aposta a : apostas) {
				if(a.getEvento().equals(e.getId().intValue())) {
					System.out.println("ENTROU");
					InfoApostaDTO infoAp = new InfoApostaDTO();
					infoAp.setId(a.getId());
					infoAp.setEstado(a.getEstado());
					infoAp.setMontante(a.getMontante());
					infoAp.setResultado(a.getResultado());
					boolean encontrouUtilizador = false;
					int index = 0;
					while(encontrouUtilizador == false && index < utilizadorCon.size()) {
						if(a.getUtilizador().equals(utilizadorCon.get(index).getId().intValue())) {
							infoAp.setUtilizador_id(utilizadorCon.get(index).getId());
							infoAp.setUtilizador_nome(utilizadorCon.get(index).getUsername());
							infoAp.setUtilizador_email(utilizadorCon.get(index).getEmail());
						}
						index ++;
					}
					infoAp.setEvento_id(e.getId());
					infoAp.setEvento_estado(e.getEstado());
					infoAp.setEvento_vencedor(e.getVencedor());
					infoAp.setEvento_oddEmpate(e.getOdd_empate());
					infoAp.setEvento_desporto(e.getDesporto());
					infoAp.setEvento_Inicio(e.getHoraInicio());
					infoAp.setEvento_Fim(e.getHoraFim());
					infoAp.setEvento_publico(e.isPublico());
					
					
					if(a.getParticipante() != null) {
						infoAp.setParticipante_id((long)a.getParticipante());
					}else {
						infoAp.setParticipante_id(null);
						infoAp.setParticipante_nome("TIE");
						infoAp.setParticipante_odd(e.getOdd_empate());
					}
						List<Participante> participanteEvento = new ArrayList<Participante>();
						for(Participante p: participanteCon) {
							if (a.getParticipante() != null && a.getParticipante() == p.getId().intValue()) {
								infoAp.setParticipante_id(p.getId());
								infoAp.setParticipante_nome(p.getNome());
								infoAp.setParticipante_equipa(p.getEquipa());
								infoAp.setParticipante_odd(p.getOdd_vencer());
								infoAp.setParticipante_pais(p.getPais());
								infoAp.setParticipante_evento(p.getId());
							}
							else if(p.getEvento().equals(e.getId())) {
								participanteEvento.add(p);
							}
						}
						
						infoAp.setOutrosParticipante(participanteEvento);
					
					
					listaApostas.add(infoAp);
					
				}
				
				
			}
		}
		return listaApostas;
	}


	@Override
	public List<InfoApostaDTO> todasApostas(List<Utilizador> utilizadorInfo, List<Evento> eventoInfo,
			List<Participante> partipantesInfo) {
List<InfoApostaDTO> listaApostas = new ArrayList<InfoApostaDTO>();
		
		ObjectMapper mapper = new ObjectMapper();
		List<Evento> eventoCon = mapper.convertValue(eventoInfo, new TypeReference<List<Evento>>(){}
				);
		
		System.out.println(eventoCon.toString());
		
		List<Participante> participanteCon = mapper.convertValue(
				partipantesInfo, 
			    new TypeReference<List<Participante>>(){}
			);
		
		List<Utilizador> utilizadorCon = mapper.convertValue(
				utilizadorInfo, 
			    new TypeReference<List<Utilizador>>(){}
			);
	
		
		System.out.println(participanteCon.toString());
		
		
		List<Aposta> apostas = apostaRepository.findAll();
		
		System.out.println(apostas.toString());
		for(Evento e: eventoCon) {
			for(Aposta a : apostas) {
				if(a.getEvento().equals(e.getId().intValue())) {
					System.out.println("ENTROU");
					InfoApostaDTO infoAp = new InfoApostaDTO();
					infoAp.setId(a.getId());
					infoAp.setEstado(a.getEstado());
					infoAp.setMontante(a.getMontante());
					infoAp.setResultado(a.getResultado());
					boolean encontrouUtilizador = false;
					int index = 0;
					while(encontrouUtilizador == false && index < utilizadorCon.size()) {
						if(a.getUtilizador().equals(utilizadorCon.get(index).getId().intValue())) {
							infoAp.setUtilizador_id(utilizadorCon.get(index).getId());
							infoAp.setUtilizador_nome(utilizadorCon.get(index).getUsername());
							infoAp.setUtilizador_email(utilizadorCon.get(index).getEmail());
						}
						index ++;
					}
					infoAp.setEvento_id(e.getId());
					infoAp.setEvento_estado(e.getEstado());
					infoAp.setEvento_vencedor(e.getVencedor());
					infoAp.setEvento_oddEmpate(e.getOdd_empate());
					infoAp.setEvento_desporto(e.getDesporto());
					infoAp.setEvento_Inicio(e.getHoraInicio());
					infoAp.setEvento_Fim(e.getHoraFim());
					infoAp.setEvento_publico(e.isPublico());
					
					if(a.getParticipante() != null) {
						infoAp.setParticipante_id((long)a.getParticipante());
					}else {
						infoAp.setParticipante_id(null);
						infoAp.setParticipante_nome("TIE");
						infoAp.setOutrosParticipante(participanteCon);
						infoAp.setParticipante_odd(e.getOdd_empate());
					}
						
						List<Participante> participanteEvento = new ArrayList<Participante>();
						for(Participante p: participanteCon) {
							if (a.getParticipante() != null && a.getParticipante() == p.getId().intValue()) {
								infoAp.setParticipante_id(p.getId());
								infoAp.setParticipante_nome(p.getNome());
								infoAp.setParticipante_equipa(p.getEquipa());
								infoAp.setParticipante_odd(p.getOdd_vencer());
								infoAp.setParticipante_pais(p.getPais());
								infoAp.setParticipante_evento(p.getId());
							}
							else if(p.getEvento().equals(e.getId())) {
								participanteEvento.add(p);
							}
						}
						infoAp.setOutrosParticipante(participanteEvento);
					
					
					listaApostas.add(infoAp);
					
				}
				
				
			}
		}
		return listaApostas;
	}

	@Override
	public List<ApostaDTO> apagaApostasUtilizador(Long utilizador) {
		List<Aposta> listaApostas = new ArrayList<Aposta>();
		List<ApostaDTO> listaApostasDTO = new ArrayList<ApostaDTO>();
		List <Aposta> apostaInfo = new ArrayList<Aposta>();
		apostaInfo = apostaRepository.findAllByUtilizador(utilizador.intValue());
		for(Aposta a: apostaInfo)
			apostaRepository.delete(a);
		
		
		
		listaApostas = apostaRepository.findByEstado("aberto");
		listaApostasDTO = apostaMapper.apostasToApostaDTOs(listaApostas);
		
		return listaApostasDTO;
		
	}

	@Override
	public List<ApostaDTO> apagaApostasEvento(Long evento) {
		List<Aposta> listaApostas = new ArrayList<Aposta>();
		List<ApostaDTO> listaApostasDTO = new ArrayList<ApostaDTO>();
		List <Aposta> apostaInfo = new ArrayList<Aposta>();
		apostaInfo = apostaRepository.findAllByEvento(evento.intValue());
		for(Aposta a: apostaInfo)
			apostaRepository.delete(a);
		
		
		
		listaApostas = apostaRepository.findByEstado("aberto");
		listaApostasDTO = apostaMapper.apostasToApostaDTOs(listaApostas);
		
		return listaApostasDTO;
	}
}
