package ewweb.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;


/**
 * A DTO for the Aposta entity.
 */
public class ApostaDTO implements Serializable {

    private Long id;

    @NotNull
    private String estado;

    @NotNull
    private Float montante;

    private Float resultado;

    @NotNull
    private Integer utilizador;

    @NotNull
    private Integer evento;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    public Float getMontante() {
        return montante;
    }

    public void setMontante(Float montante) {
        this.montante = montante;
    }
    public Float getResultado() {
        return resultado;
    }

    public void setResultado(Float resultado) {
        this.resultado = resultado;
    }
    public Integer getUtilizador() {
        return utilizador;
    }

    public void setUtilizador(Integer utilizador) {
        this.utilizador = utilizador;
    }
    public Integer getEvento() {
        return evento;
    }

    public void setEvento(Integer evento) {
        this.evento = evento;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ApostaDTO apostaDTO = (ApostaDTO) o;

        if ( ! Objects.equals(id, apostaDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "ApostaDTO{" +
            "id=" + id +
            ", estado='" + estado + "'" +
            ", montante='" + montante + "'" +
            ", resultado='" + resultado + "'" +
            ", utilizador='" + utilizador + "'" +
            ", evento='" + evento + "'" +
            '}';
    }
}
