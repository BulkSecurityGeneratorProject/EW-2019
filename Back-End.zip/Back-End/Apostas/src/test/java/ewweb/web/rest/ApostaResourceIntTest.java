package ewweb.web.rest;

import ewweb.ApostasApp;

import ewweb.domain.Aposta;
import ewweb.repository.ApostaRepository;
import ewweb.service.ApostaService;
import ewweb.repository.search.ApostaSearchRepository;
import ewweb.service.dto.ApostaDTO;
import ewweb.service.mapper.ApostaMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ApostaResource REST controller.
 *
 * @see ApostaResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApostasApp.class)
public class ApostaResourceIntTest {

    private static final String DEFAULT_ESTADO = "AAAAAAAAAA";
    private static final String UPDATED_ESTADO = "BBBBBBBBBB";

    private static final Float DEFAULT_MONTANTE = 1F;
    private static final Float UPDATED_MONTANTE = 2F;

    private static final Float DEFAULT_RESULTADO = 1F;
    private static final Float UPDATED_RESULTADO = 2F;

    private static final Integer DEFAULT_UTILIZADOR = 1;
    private static final Integer UPDATED_UTILIZADOR = 2;

    private static final Integer DEFAULT_EVENTO = 1;
    private static final Integer UPDATED_EVENTO = 2;

    private static final Integer DEFAULT_PARTICIPANTE = 1;
    private static final Integer UPDATED_PARTICIPANTE = 2;

    @Inject
    private ApostaRepository apostaRepository;

    @Inject
    private ApostaMapper apostaMapper;

    @Inject
    private ApostaService apostaService;

    @Inject
    private ApostaSearchRepository apostaSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restApostaMockMvc;

    private Aposta aposta;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ApostaResource apostaResource = new ApostaResource();
        ReflectionTestUtils.setField(apostaResource, "apostaService", apostaService);
        this.restApostaMockMvc = MockMvcBuilders.standaloneSetup(apostaResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Aposta createEntity(EntityManager em) {
        Aposta aposta = new Aposta()
                .estado(DEFAULT_ESTADO)
                .montante(DEFAULT_MONTANTE)
                .resultado(DEFAULT_RESULTADO)
                .utilizador(DEFAULT_UTILIZADOR)
                .evento(DEFAULT_EVENTO)
                .participante(DEFAULT_PARTICIPANTE);
        return aposta;
    }

    @Before
    public void initTest() {
        apostaSearchRepository.deleteAll();
        aposta = createEntity(em);
    }

    @Test
    @Transactional
    public void createAposta() throws Exception {
        int databaseSizeBeforeCreate = apostaRepository.findAll().size();

        // Create the Aposta
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);

        restApostaMockMvc.perform(post("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(apostaDTO)))
            .andExpect(status().isCreated());

        // Validate the Aposta in the database
        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeCreate + 1);
        Aposta testAposta = apostaList.get(apostaList.size() - 1);
        assertThat(testAposta.getEstado()).isEqualTo(DEFAULT_ESTADO);
        assertThat(testAposta.getMontante()).isEqualTo(DEFAULT_MONTANTE);
        assertThat(testAposta.getResultado()).isEqualTo(DEFAULT_RESULTADO);
        assertThat(testAposta.getUtilizador()).isEqualTo(DEFAULT_UTILIZADOR);
        assertThat(testAposta.getEvento()).isEqualTo(DEFAULT_EVENTO);
        assertThat(testAposta.getParticipante()).isEqualTo(DEFAULT_PARTICIPANTE);

        // Validate the Aposta in ElasticSearch
        Aposta apostaEs = apostaSearchRepository.findOne(testAposta.getId());
        assertThat(apostaEs).isEqualToComparingFieldByField(testAposta);
    }

    @Test
    @Transactional
    public void createApostaWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = apostaRepository.findAll().size();

        // Create the Aposta with an existing ID
        Aposta existingAposta = new Aposta();
        existingAposta.setId(1L);
        ApostaDTO existingApostaDTO = apostaMapper.apostaToApostaDTO(existingAposta);

        // An entity with an existing ID cannot be created, so this API call must fail
        restApostaMockMvc.perform(post("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(existingApostaDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Alice in the database
        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkEstadoIsRequired() throws Exception {
        int databaseSizeBeforeTest = apostaRepository.findAll().size();
        // set the field null
        aposta.setEstado(null);

        // Create the Aposta, which fails.
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);

        restApostaMockMvc.perform(post("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(apostaDTO)))
            .andExpect(status().isBadRequest());

        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkMontanteIsRequired() throws Exception {
        int databaseSizeBeforeTest = apostaRepository.findAll().size();
        // set the field null
        aposta.setMontante(null);

        // Create the Aposta, which fails.
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);

        restApostaMockMvc.perform(post("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(apostaDTO)))
            .andExpect(status().isBadRequest());

        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkUtilizadorIsRequired() throws Exception {
        int databaseSizeBeforeTest = apostaRepository.findAll().size();
        // set the field null
        aposta.setUtilizador(null);

        // Create the Aposta, which fails.
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);

        restApostaMockMvc.perform(post("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(apostaDTO)))
            .andExpect(status().isBadRequest());

        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkEventoIsRequired() throws Exception {
        int databaseSizeBeforeTest = apostaRepository.findAll().size();
        // set the field null
        aposta.setEvento(null);

        // Create the Aposta, which fails.
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);

        restApostaMockMvc.perform(post("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(apostaDTO)))
            .andExpect(status().isBadRequest());

        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllApostas() throws Exception {
        // Initialize the database
        apostaRepository.saveAndFlush(aposta);

        // Get all the apostaList
        restApostaMockMvc.perform(get("/api/apostas?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(aposta.getId().intValue())))
            .andExpect(jsonPath("$.[*].estado").value(hasItem(DEFAULT_ESTADO.toString())))
            .andExpect(jsonPath("$.[*].montante").value(hasItem(DEFAULT_MONTANTE.doubleValue())))
            .andExpect(jsonPath("$.[*].resultado").value(hasItem(DEFAULT_RESULTADO.doubleValue())))
            .andExpect(jsonPath("$.[*].utilizador").value(hasItem(DEFAULT_UTILIZADOR)))
            .andExpect(jsonPath("$.[*].evento").value(hasItem(DEFAULT_EVENTO)))
            .andExpect(jsonPath("$.[*].participante").value(hasItem(DEFAULT_PARTICIPANTE)));
    }

    @Test
    @Transactional
    public void getAposta() throws Exception {
        // Initialize the database
        apostaRepository.saveAndFlush(aposta);

        // Get the aposta
        restApostaMockMvc.perform(get("/api/apostas/{id}", aposta.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(aposta.getId().intValue()))
            .andExpect(jsonPath("$.estado").value(DEFAULT_ESTADO.toString()))
            .andExpect(jsonPath("$.montante").value(DEFAULT_MONTANTE.doubleValue()))
            .andExpect(jsonPath("$.resultado").value(DEFAULT_RESULTADO.doubleValue()))
            .andExpect(jsonPath("$.utilizador").value(DEFAULT_UTILIZADOR))
            .andExpect(jsonPath("$.evento").value(DEFAULT_EVENTO))
            .andExpect(jsonPath("$.participante").value(DEFAULT_PARTICIPANTE));
    }

    @Test
    @Transactional
    public void getNonExistingAposta() throws Exception {
        // Get the aposta
        restApostaMockMvc.perform(get("/api/apostas/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateAposta() throws Exception {
        // Initialize the database
        apostaRepository.saveAndFlush(aposta);
        apostaSearchRepository.save(aposta);
        int databaseSizeBeforeUpdate = apostaRepository.findAll().size();

        // Update the aposta
        Aposta updatedAposta = apostaRepository.findOne(aposta.getId());
        updatedAposta
                .estado(UPDATED_ESTADO)
                .montante(UPDATED_MONTANTE)
                .resultado(UPDATED_RESULTADO)
                .utilizador(UPDATED_UTILIZADOR)
                .evento(UPDATED_EVENTO)
                .participante(UPDATED_PARTICIPANTE);
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(updatedAposta);

        restApostaMockMvc.perform(put("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(apostaDTO)))
            .andExpect(status().isOk());

        // Validate the Aposta in the database
        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeUpdate);
        Aposta testAposta = apostaList.get(apostaList.size() - 1);
        assertThat(testAposta.getEstado()).isEqualTo(UPDATED_ESTADO);
        assertThat(testAposta.getMontante()).isEqualTo(UPDATED_MONTANTE);
        assertThat(testAposta.getResultado()).isEqualTo(UPDATED_RESULTADO);
        assertThat(testAposta.getUtilizador()).isEqualTo(UPDATED_UTILIZADOR);
        assertThat(testAposta.getEvento()).isEqualTo(UPDATED_EVENTO);
        assertThat(testAposta.getParticipante()).isEqualTo(UPDATED_PARTICIPANTE);

        // Validate the Aposta in ElasticSearch
        Aposta apostaEs = apostaSearchRepository.findOne(testAposta.getId());
        assertThat(apostaEs).isEqualToComparingFieldByField(testAposta);
    }

    @Test
    @Transactional
    public void updateNonExistingAposta() throws Exception {
        int databaseSizeBeforeUpdate = apostaRepository.findAll().size();

        // Create the Aposta
        ApostaDTO apostaDTO = apostaMapper.apostaToApostaDTO(aposta);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restApostaMockMvc.perform(put("/api/apostas")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(apostaDTO)))
            .andExpect(status().isCreated());

        // Validate the Aposta in the database
        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteAposta() throws Exception {
        // Initialize the database
        apostaRepository.saveAndFlush(aposta);
        apostaSearchRepository.save(aposta);
        int databaseSizeBeforeDelete = apostaRepository.findAll().size();

        // Get the aposta
        restApostaMockMvc.perform(delete("/api/apostas/{id}", aposta.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean apostaExistsInEs = apostaSearchRepository.exists(aposta.getId());
        assertThat(apostaExistsInEs).isFalse();

        // Validate the database is empty
        List<Aposta> apostaList = apostaRepository.findAll();
        assertThat(apostaList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchAposta() throws Exception {
        // Initialize the database
        apostaRepository.saveAndFlush(aposta);
        apostaSearchRepository.save(aposta);

        // Search the aposta
        restApostaMockMvc.perform(get("/api/_search/apostas?query=id:" + aposta.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(aposta.getId().intValue())))
            .andExpect(jsonPath("$.[*].estado").value(hasItem(DEFAULT_ESTADO.toString())))
            .andExpect(jsonPath("$.[*].montante").value(hasItem(DEFAULT_MONTANTE.doubleValue())))
            .andExpect(jsonPath("$.[*].resultado").value(hasItem(DEFAULT_RESULTADO.doubleValue())))
            .andExpect(jsonPath("$.[*].utilizador").value(hasItem(DEFAULT_UTILIZADOR)))
            .andExpect(jsonPath("$.[*].evento").value(hasItem(DEFAULT_EVENTO)))
            .andExpect(jsonPath("$.[*].participante").value(hasItem(DEFAULT_PARTICIPANTE)));
    }
}
