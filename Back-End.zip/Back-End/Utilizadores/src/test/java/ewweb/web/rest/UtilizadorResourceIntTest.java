package ewweb.web.rest;

import ewweb.UtilizadoresApp;

import ewweb.domain.Utilizador;
import ewweb.repository.UtilizadorRepository;
import ewweb.service.UtilizadorService;
import ewweb.service.dto.UtilizadorDTO;
import ewweb.service.mapper.UtilizadorMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the UtilizadorResource REST controller.
 *
 * @see UtilizadorResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = UtilizadoresApp.class)
public class UtilizadorResourceIntTest {

    private static final String DEFAULT_USERNAME = "AAAAAAAAAA";
    private static final String UPDATED_USERNAME = "BBBBBBBBBB";

    private static final String DEFAULT_PASSWORD = "AAAAAAAAAA";
    private static final String UPDATED_PASSWORD = "BBBBBBBBBB";

    private static final String DEFAULT_EMAIL = "AAAAAAAAAA";
    private static final String UPDATED_EMAIL = "BBBBBBBBBB";

    private static final Float DEFAULT_PLAFOND = 1F;
    private static final Float UPDATED_PLAFOND = 2F;

    @Inject
    private UtilizadorRepository utilizadorRepository;

    @Inject
    private UtilizadorMapper utilizadorMapper;

    @Inject
    private UtilizadorService utilizadorService;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restUtilizadorMockMvc;

    private Utilizador utilizador;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        UtilizadorResource utilizadorResource = new UtilizadorResource();
        ReflectionTestUtils.setField(utilizadorResource, "utilizadorService", utilizadorService);
        this.restUtilizadorMockMvc = MockMvcBuilders.standaloneSetup(utilizadorResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Utilizador createEntity(EntityManager em) {
        Utilizador utilizador = new Utilizador()
                .username(DEFAULT_USERNAME)
                .password(DEFAULT_PASSWORD)
                .email(DEFAULT_EMAIL)
                .plafond(DEFAULT_PLAFOND);
        return utilizador;
    }

    @Before
    public void initTest() {
        utilizador = createEntity(em);
    }

    @Test
    @Transactional
    public void createUtilizador() throws Exception {
        int databaseSizeBeforeCreate = utilizadorRepository.findAll().size();

        // Create the Utilizador
        UtilizadorDTO utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);

        restUtilizadorMockMvc.perform(post("/api/utilizadors")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(utilizadorDTO)))
            .andExpect(status().isCreated());

        // Validate the Utilizador in the database
        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeCreate + 1);
        Utilizador testUtilizador = utilizadorList.get(utilizadorList.size() - 1);
        assertThat(testUtilizador.getUsername()).isEqualTo(DEFAULT_USERNAME);
        assertThat(testUtilizador.getPassword()).isEqualTo(DEFAULT_PASSWORD);
        assertThat(testUtilizador.getEmail()).isEqualTo(DEFAULT_EMAIL);
        assertThat(testUtilizador.getPlafond()).isEqualTo(DEFAULT_PLAFOND);
    }

    @Test
    @Transactional
    public void createUtilizadorWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = utilizadorRepository.findAll().size();

        // Create the Utilizador with an existing ID
        Utilizador existingUtilizador = new Utilizador();
        existingUtilizador.setId(1L);
        UtilizadorDTO existingUtilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(existingUtilizador);

        // An entity with an existing ID cannot be created, so this API call must fail
        restUtilizadorMockMvc.perform(post("/api/utilizadors")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(existingUtilizadorDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Alice in the database
        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkUsernameIsRequired() throws Exception {
        int databaseSizeBeforeTest = utilizadorRepository.findAll().size();
        // set the field null
        utilizador.setUsername(null);

        // Create the Utilizador, which fails.
        UtilizadorDTO utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);

        restUtilizadorMockMvc.perform(post("/api/utilizadors")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(utilizadorDTO)))
            .andExpect(status().isBadRequest());

        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkPasswordIsRequired() throws Exception {
        int databaseSizeBeforeTest = utilizadorRepository.findAll().size();
        // set the field null
        utilizador.setPassword(null);

        // Create the Utilizador, which fails.
        UtilizadorDTO utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);

        restUtilizadorMockMvc.perform(post("/api/utilizadors")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(utilizadorDTO)))
            .andExpect(status().isBadRequest());

        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkEmailIsRequired() throws Exception {
        int databaseSizeBeforeTest = utilizadorRepository.findAll().size();
        // set the field null
        utilizador.setEmail(null);

        // Create the Utilizador, which fails.
        UtilizadorDTO utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);

        restUtilizadorMockMvc.perform(post("/api/utilizadors")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(utilizadorDTO)))
            .andExpect(status().isBadRequest());

        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllUtilizadors() throws Exception {
        // Initialize the database
        utilizadorRepository.saveAndFlush(utilizador);

        // Get all the utilizadorList
        restUtilizadorMockMvc.perform(get("/api/utilizadors?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(utilizador.getId().intValue())))
            .andExpect(jsonPath("$.[*].username").value(hasItem(DEFAULT_USERNAME.toString())))
            .andExpect(jsonPath("$.[*].password").value(hasItem(DEFAULT_PASSWORD.toString())))
            .andExpect(jsonPath("$.[*].email").value(hasItem(DEFAULT_EMAIL.toString())))
            .andExpect(jsonPath("$.[*].plafond").value(hasItem(DEFAULT_PLAFOND.doubleValue())));
    }

    @Test
    @Transactional
    public void getUtilizador() throws Exception {
        // Initialize the database
        utilizadorRepository.saveAndFlush(utilizador);

        // Get the utilizador
        restUtilizadorMockMvc.perform(get("/api/utilizadors/{id}", utilizador.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(utilizador.getId().intValue()))
            .andExpect(jsonPath("$.username").value(DEFAULT_USERNAME.toString()))
            .andExpect(jsonPath("$.password").value(DEFAULT_PASSWORD.toString()))
            .andExpect(jsonPath("$.email").value(DEFAULT_EMAIL.toString()))
            .andExpect(jsonPath("$.plafond").value(DEFAULT_PLAFOND.doubleValue()));
    }

    @Test
    @Transactional
    public void getNonExistingUtilizador() throws Exception {
        // Get the utilizador
        restUtilizadorMockMvc.perform(get("/api/utilizadors/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateUtilizador() throws Exception {
        // Initialize the database
        utilizadorRepository.saveAndFlush(utilizador);
        int databaseSizeBeforeUpdate = utilizadorRepository.findAll().size();

        // Update the utilizador
        Utilizador updatedUtilizador = utilizadorRepository.findOne(utilizador.getId());
        updatedUtilizador
                .username(UPDATED_USERNAME)
                .password(UPDATED_PASSWORD)
                .email(UPDATED_EMAIL)
                .plafond(UPDATED_PLAFOND);
        UtilizadorDTO utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(updatedUtilizador);

        restUtilizadorMockMvc.perform(put("/api/utilizadors")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(utilizadorDTO)))
            .andExpect(status().isOk());

        // Validate the Utilizador in the database
        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeUpdate);
        Utilizador testUtilizador = utilizadorList.get(utilizadorList.size() - 1);
        assertThat(testUtilizador.getUsername()).isEqualTo(UPDATED_USERNAME);
        assertThat(testUtilizador.getPassword()).isEqualTo(UPDATED_PASSWORD);
        assertThat(testUtilizador.getEmail()).isEqualTo(UPDATED_EMAIL);
        assertThat(testUtilizador.getPlafond()).isEqualTo(UPDATED_PLAFOND);
    }

    @Test
    @Transactional
    public void updateNonExistingUtilizador() throws Exception {
        int databaseSizeBeforeUpdate = utilizadorRepository.findAll().size();

        // Create the Utilizador
        UtilizadorDTO utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restUtilizadorMockMvc.perform(put("/api/utilizadors")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(utilizadorDTO)))
            .andExpect(status().isCreated());

        // Validate the Utilizador in the database
        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteUtilizador() throws Exception {
        // Initialize the database
        utilizadorRepository.saveAndFlush(utilizador);
        int databaseSizeBeforeDelete = utilizadorRepository.findAll().size();

        // Get the utilizador
        restUtilizadorMockMvc.perform(delete("/api/utilizadors/{id}", utilizador.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Utilizador> utilizadorList = utilizadorRepository.findAll();
        assertThat(utilizadorList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
