package ewweb.repository;

import ewweb.domain.Grupo;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the Grupo entity.
 */
@SuppressWarnings("unused")
public interface GrupoRepository extends JpaRepository<Grupo,Long> {

    @Query("select distinct grupo from Grupo grupo left join fetch grupo.modulos")
    List<Grupo> findAllWithEagerRelationships();

    @Query("select grupo from Grupo grupo left join fetch grupo.modulos where grupo.id =:id")
    Grupo findOneWithEagerRelationships(@Param("id") Long id);

}
