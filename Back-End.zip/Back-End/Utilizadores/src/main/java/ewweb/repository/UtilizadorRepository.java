package ewweb.repository;

import ewweb.domain.Utilizador;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the Utilizador entity.
 */
@SuppressWarnings("unused")
public interface UtilizadorRepository extends JpaRepository<Utilizador,Long> {

    @Query("select distinct utilizador from Utilizador utilizador left join fetch utilizador.grupos")
    List<Utilizador> findAllWithEagerRelationships();

    @Query("select utilizador from Utilizador utilizador left join fetch utilizador.grupos where utilizador.id =:id")
    Utilizador findOneWithEagerRelationships(@Param("id") Long id);
    
    Utilizador findByEmail(@Param("email") String email);
    
    Utilizador findById(@Param("id") Long id);

}
