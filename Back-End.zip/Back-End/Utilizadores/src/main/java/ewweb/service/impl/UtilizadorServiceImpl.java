package ewweb.service.impl;

import ewweb.service.UtilizadorService;
import ewweb.domain.Grupo;
import ewweb.domain.Utilizador;
import ewweb.repository.UtilizadorRepository;
import ewweb.service.dto.UtilizadorDTO;
import ewweb.service.mapper.UtilizadorMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing Utilizador.
 */
@Service
@Transactional
public class UtilizadorServiceImpl implements UtilizadorService{

    private final Logger log = LoggerFactory.getLogger(UtilizadorServiceImpl.class);
    
    @Inject
    private UtilizadorRepository utilizadorRepository;

    @Inject
    private UtilizadorMapper utilizadorMapper;

    /**
     * Save a utilizador.
     *
     * @param utilizadorDTO the entity to save
     * @return the persisted entity
     */
    public UtilizadorDTO save(UtilizadorDTO utilizadorDTO) {
        log.debug("Request to save Utilizador : {}", utilizadorDTO);
        Utilizador utilizador = utilizadorMapper.utilizadorDTOToUtilizador(utilizadorDTO);
        utilizador = utilizadorRepository.save(utilizador);
        UtilizadorDTO result = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);
        return result;
    }

    /**
     *  Get all the utilizadors.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<UtilizadorDTO> findAll() {
        log.debug("Request to get all Utilizadors");
        List<UtilizadorDTO> result = utilizadorRepository.findAllWithEagerRelationships().stream()
            .map(utilizadorMapper::utilizadorToUtilizadorDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one utilizador by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public UtilizadorDTO findOne(Long id) {
        log.debug("Request to get Utilizador : {}", id);
        Utilizador utilizador = utilizadorRepository.findOneWithEagerRelationships(id);
        UtilizadorDTO utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);
        return utilizadorDTO;
    }

    /**
     *  Delete the  utilizador by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Utilizador : {}", id);
        utilizadorRepository.delete(id);
    }

	@Override
	public UtilizadorDTO registaUtilizador(String username, String password, String email, float plafond) {
		Utilizador utilizador = new Utilizador();
		UtilizadorDTO utilizadorDTO = new UtilizadorDTO();
		
		//Verifica se o email ja esta registado
		Utilizador jaExiste = utilizadorRepository.findByEmail(email);
		
		if(jaExiste == null) {
			Set<Grupo> grupos = new HashSet<Grupo>();
			Grupo grupo = new Grupo();
			grupo.setGroupname("normal");
			grupo.setId(3L);
			grupos.add(grupo);
			
			utilizador.setUsername(username);
			utilizador.setPassword(password);
			utilizador.setEmail(email);
			utilizador.setPlafond(plafond);
			utilizador.setGrupos(grupos);
			
			utilizadorRepository.saveAndFlush(utilizador);
			utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);
		}
		
		return utilizadorDTO;
	}

	@Override
	public UtilizadorDTO perfilUtilizador(String email) {
		Utilizador utilizador = new Utilizador();
		UtilizadorDTO utilizadorDTO = new UtilizadorDTO();
		
		utilizador = utilizadorRepository.findByEmail(email);
		utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);
		return utilizadorDTO;
	}

	@Override
	public List<UtilizadorDTO> todosUtilizador() {
		List<Utilizador> listaUtilizadores = new ArrayList<Utilizador>();
		List<UtilizadorDTO> listaUtilizadorDTO = new ArrayList<UtilizadorDTO>();
		
		listaUtilizadores = utilizadorRepository.findAll();
		listaUtilizadorDTO = utilizadorMapper.utilizadorsToUtilizadorDTOs(listaUtilizadores);
		return listaUtilizadorDTO;
	}

	@Override
	public List<UtilizadorDTO> eliminaUtilizador(long id) {
		List<Utilizador> listaUtilizadores = new ArrayList<Utilizador>();
		List<UtilizadorDTO> listaUtilizadorDTO = new ArrayList<UtilizadorDTO>();
		Utilizador utilizador = new Utilizador();
		
		utilizador = utilizadorRepository.findById(id);
		if(utilizador != null)
			utilizadorRepository.delete(utilizador);
		
		listaUtilizadores = utilizadorRepository.findAll();
		listaUtilizadorDTO = utilizadorMapper.utilizadorsToUtilizadorDTOs(listaUtilizadores);
		return listaUtilizadorDTO;
	}

	@Override
	public UtilizadorDTO plafondUtilizador(String email, float plafond) {
		Utilizador utilizador = new Utilizador();
		UtilizadorDTO utilizadorDTO = new UtilizadorDTO();
		
		utilizador = utilizadorRepository.findByEmail(email);
		utilizador.setPlafond(plafond);
		utilizadorRepository.saveAndFlush(utilizador);
		
		utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);
		return utilizadorDTO;
		
	}

	@Override
	public UtilizadorDTO premiumUtilizador(long id) {
		Utilizador utilizador = new Utilizador();
		UtilizadorDTO utilizadorDTO = new UtilizadorDTO();
		
		utilizador = utilizadorRepository.findById(id);
		
		Float plafond = utilizador.getPlafond() - 10;
		utilizador.setPlafond(plafond);
		
		Set<Grupo> grupos = utilizador.getGrupos();
		Grupo grupo = new Grupo();
		grupo.setGroupname("premium");
		grupo.setId(2L);
		grupos.add(grupo);
		utilizador.setGrupos(grupos);
		
		utilizadorRepository.saveAndFlush(utilizador);
		
		utilizadorDTO = utilizadorMapper.utilizadorToUtilizadorDTO(utilizador);
		return utilizadorDTO;
	}
}
