package ewweb.service;

import ewweb.service.dto.ModuloDTO;
import java.util.List;

/**
 * Service Interface for managing Modulo.
 */
public interface ModuloService {

    /**
     * Save a modulo.
     *
     * @param moduloDTO the entity to save
     * @return the persisted entity
     */
    ModuloDTO save(ModuloDTO moduloDTO);

    /**
     *  Get all the modulos.
     *  
     *  @return the list of entities
     */
    List<ModuloDTO> findAll();

    /**
     *  Get the "id" modulo.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    ModuloDTO findOne(Long id);

    /**
     *  Delete the "id" modulo.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);
}
