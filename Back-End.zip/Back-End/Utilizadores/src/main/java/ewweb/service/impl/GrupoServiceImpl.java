package ewweb.service.impl;

import ewweb.service.GrupoService;
import ewweb.domain.Grupo;
import ewweb.repository.GrupoRepository;
import ewweb.service.dto.GrupoDTO;
import ewweb.service.mapper.GrupoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing Grupo.
 */
@Service
@Transactional
public class GrupoServiceImpl implements GrupoService{

    private final Logger log = LoggerFactory.getLogger(GrupoServiceImpl.class);
    
    @Inject
    private GrupoRepository grupoRepository;

    @Inject
    private GrupoMapper grupoMapper;

    /**
     * Save a grupo.
     *
     * @param grupoDTO the entity to save
     * @return the persisted entity
     */
    public GrupoDTO save(GrupoDTO grupoDTO) {
        log.debug("Request to save Grupo : {}", grupoDTO);
        Grupo grupo = grupoMapper.grupoDTOToGrupo(grupoDTO);
        grupo = grupoRepository.save(grupo);
        GrupoDTO result = grupoMapper.grupoToGrupoDTO(grupo);
        return result;
    }

    /**
     *  Get all the grupos.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<GrupoDTO> findAll() {
        log.debug("Request to get all Grupos");
        List<GrupoDTO> result = grupoRepository.findAllWithEagerRelationships().stream()
            .map(grupoMapper::grupoToGrupoDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one grupo by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public GrupoDTO findOne(Long id) {
        log.debug("Request to get Grupo : {}", id);
        Grupo grupo = grupoRepository.findOneWithEagerRelationships(id);
        GrupoDTO grupoDTO = grupoMapper.grupoToGrupoDTO(grupo);
        return grupoDTO;
    }

    /**
     *  Delete the  grupo by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Grupo : {}", id);
        grupoRepository.delete(id);
    }
}
