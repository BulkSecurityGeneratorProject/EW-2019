package ewweb.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Modulo entity.
 */
public class ModuloDTO implements Serializable {

    private Long id;

    @NotNull
    private String moduleid;

    @NotNull
    private String modulename;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getModuleid() {
        return moduleid;
    }

    public void setModuleid(String moduleid) {
        this.moduleid = moduleid;
    }
    public String getModulename() {
        return modulename;
    }

    public void setModulename(String modulename) {
        this.modulename = modulename;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ModuloDTO moduloDTO = (ModuloDTO) o;

        if ( ! Objects.equals(id, moduloDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "ModuloDTO{" +
            "id=" + id +
            ", moduleid='" + moduleid + "'" +
            ", modulename='" + modulename + "'" +
            '}';
    }
}
