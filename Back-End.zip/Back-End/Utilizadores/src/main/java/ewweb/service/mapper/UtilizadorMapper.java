package ewweb.service.mapper;

import ewweb.domain.*;
import ewweb.service.dto.UtilizadorDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Utilizador and its DTO UtilizadorDTO.
 */
@Mapper(componentModel = "spring", uses = {GrupoMapper.class, })
public interface UtilizadorMapper {

    UtilizadorDTO utilizadorToUtilizadorDTO(Utilizador utilizador);

    List<UtilizadorDTO> utilizadorsToUtilizadorDTOs(List<Utilizador> utilizadors);

    Utilizador utilizadorDTOToUtilizador(UtilizadorDTO utilizadorDTO);

    List<Utilizador> utilizadorDTOsToUtilizadors(List<UtilizadorDTO> utilizadorDTOs);

    default Grupo grupoFromId(Long id) {
        if (id == null) {
            return null;
        }
        Grupo grupo = new Grupo();
        grupo.setId(id);
        return grupo;
    }
}
