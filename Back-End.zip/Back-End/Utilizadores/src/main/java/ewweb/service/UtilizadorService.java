package ewweb.service;

import ewweb.service.dto.UtilizadorDTO;
import java.util.List;

/**
 * Service Interface for managing Utilizador.
 */
public interface UtilizadorService {

    /**
     * Save a utilizador.
     *
     * @param utilizadorDTO the entity to save
     * @return the persisted entity
     */
    UtilizadorDTO save(UtilizadorDTO utilizadorDTO);

    /**
     *  Get all the utilizadors.
     *  
     *  @return the list of entities
     */
    List<UtilizadorDTO> findAll();

    /**
     *  Get the "id" utilizador.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    UtilizadorDTO findOne(Long id);

    /**
     *  Delete the "id" utilizador.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

	UtilizadorDTO registaUtilizador(String username, String password, String email, float plafond);

	UtilizadorDTO perfilUtilizador(String email);

	List<UtilizadorDTO> todosUtilizador();

	List<UtilizadorDTO> eliminaUtilizador(long id);

	UtilizadorDTO plafondUtilizador(String email, float plafond);

	UtilizadorDTO premiumUtilizador(long id);

	UtilizadorDTO existeUtilizador(String username, String password);
}
