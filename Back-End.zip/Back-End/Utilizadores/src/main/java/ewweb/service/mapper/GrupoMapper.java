package ewweb.service.mapper;

import ewweb.domain.*;
import ewweb.service.dto.GrupoDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Grupo and its DTO GrupoDTO.
 */
@Mapper(componentModel = "spring", uses = {ModuloMapper.class, })
public interface GrupoMapper {

    GrupoDTO grupoToGrupoDTO(Grupo grupo);

    List<GrupoDTO> gruposToGrupoDTOs(List<Grupo> grupos);

    @Mapping(target = "utilizadors", ignore = true)
    Grupo grupoDTOToGrupo(GrupoDTO grupoDTO);

    List<Grupo> grupoDTOsToGrupos(List<GrupoDTO> grupoDTOs);

    default Modulo moduloFromId(Long id) {
        if (id == null) {
            return null;
        }
        Modulo modulo = new Modulo();
        modulo.setId(id);
        return modulo;
    }
}
