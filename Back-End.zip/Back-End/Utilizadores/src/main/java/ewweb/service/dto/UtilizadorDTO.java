package ewweb.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Utilizador entity.
 */
public class UtilizadorDTO implements Serializable {

    private Long id;

    @NotNull
    private String username;

    @NotNull
    private String password;

    @NotNull
    private String email;

    private Float plafond;


    private Set<GrupoDTO> grupos = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public Float getPlafond() {
        return plafond;
    }

    public void setPlafond(Float plafond) {
        this.plafond = plafond;
    }

    public Set<GrupoDTO> getGrupos() {
        return grupos;
    }

    public void setGrupos(Set<GrupoDTO> grupos) {
        this.grupos = grupos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UtilizadorDTO utilizadorDTO = (UtilizadorDTO) o;

        if ( ! Objects.equals(id, utilizadorDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UtilizadorDTO{" +
            "id=" + id +
            ", username='" + username + "'" +
            ", password='" + password + "'" +
            ", email='" + email + "'" +
            ", plafond='" + plafond + "'" +
            '}';
    }
}
