package ewweb.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Grupo entity.
 */
public class GrupoDTO implements Serializable {

    private Long id;

    @NotNull
    private String groupname;


    private Set<ModuloDTO> modulos = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public Set<ModuloDTO> getModulos() {
        return modulos;
    }

    public void setModulos(Set<ModuloDTO> modulos) {
        this.modulos = modulos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        GrupoDTO grupoDTO = (GrupoDTO) o;

        if ( ! Objects.equals(id, grupoDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "GrupoDTO{" +
            "id=" + id +
            ", groupname='" + groupname + "'" +
            '}';
    }
}
