-- Aposta [ent5]
alter table `aposta`  add column  `resultado`  integer;


-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table `user`  add column  `group_oid`  integer;
alter table `user`   add index fk_user_group_2 (`group_oid`), add constraint fk_user_group_2 foreign key (`group_oid`) references `group` (`oid`);


-- REL FK: ApostaToUser [rel2#role4]
alter table `aposta`   add index fk_user_aposta (`oid`), add constraint fk_user_aposta foreign key (`oid`) references `aposta` (`aposta_oid`);


