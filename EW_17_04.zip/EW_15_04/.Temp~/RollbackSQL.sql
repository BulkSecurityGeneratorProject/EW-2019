-- Aposta [ent5]
alter table `aposta`   drop column  `resultado`;
