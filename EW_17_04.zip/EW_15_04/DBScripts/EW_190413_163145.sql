-- Evento [ent3]
alter table `evento`  add column  `oid`  integer  not null;
alter table `evento`  add column  `evento_oid`  integer  not null;


-- Participante [ent4]
alter table `participante`  add column  `pais`  varchar(255);


-- Participante_Evento [rel1]
alter table `participante`  add column  `evento_oid`  integer;
alter table `participante`   add index fk_participante_evento (`evento_oid`), add constraint fk_participante_evento foreign key (`evento_oid`) references `evento` (`evento_oid`);


