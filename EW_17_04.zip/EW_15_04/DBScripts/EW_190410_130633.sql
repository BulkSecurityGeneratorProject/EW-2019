-- Participante [ent4]
alter table `participante`  add column  `pais`  varchar(255);


