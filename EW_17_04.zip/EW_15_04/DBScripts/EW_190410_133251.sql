-- Participante_Evento [rel1]
alter table `participante`  add column  `evento_oid`  integer;
alter table `participante`   add index fk_participante_evento_2 (`evento_oid`), add constraint fk_participante_evento_2 foreign key (`evento_oid`) references `evento` (`oid`);


