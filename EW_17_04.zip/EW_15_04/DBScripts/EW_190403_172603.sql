-- Evento [ent3]
alter table `evento`  add column  `visibilidade`  varchar(255);


