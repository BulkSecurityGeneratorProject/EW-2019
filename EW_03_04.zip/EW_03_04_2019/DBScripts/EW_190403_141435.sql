-- User [User]
alter table `user`  add column  `plafond`  decimal(19,2);


-- Evento [ent3]
alter table `evento`  add column  `desporto`  varchar(255);


