insert into module values(1,"area3","Administrador");
insert into module values (2,"page2","Eventos");
insert into module values(3, "page5", "Apostas");

insert into group values(1,"administrador",1);
insert into group values(2,"premium",2);
insert into group values(3,"normal", 3);

insert into user values(1,"admin","admin",null,null,1);
insert into user values(2,"joao","joao","Jonas_Filipe_9@hotmail.com", 10000, 2);
insert into user values(3,"user","user","user",30,3);

insert into group_module values(1,1);
insert into group_module values(1,2);
insert into group_module values(1,3);
insert into group_module values(2,2);
insert into group_module values(2,3);
insert into group_module values(3,3);





