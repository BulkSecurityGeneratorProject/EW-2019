-- Aposta [ent5]
alter table `aposta`  add column  `estado`  varchar(255);
alter table `aposta`  add column  `montante`  integer;


