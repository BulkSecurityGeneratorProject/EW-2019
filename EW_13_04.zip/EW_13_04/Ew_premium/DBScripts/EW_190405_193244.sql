-- Evento_Participante [rel3]
create table `evento_participante` (
   `evento_oid`  integer not null,
   `participante_oid`  integer not null,
  primary key (`evento_oid`, `participante_oid`)
);
alter table `evento_participante`   add index fk_evento_participante_evento (`evento_oid`), add constraint fk_evento_participante_evento foreign key (`evento_oid`) references `evento` (`oid`);
alter table `evento_participante`   add index fk_evento_participante_partici (`participante_oid`), add constraint fk_evento_participante_partici foreign key (`participante_oid`) references `participante` (`oid`);


